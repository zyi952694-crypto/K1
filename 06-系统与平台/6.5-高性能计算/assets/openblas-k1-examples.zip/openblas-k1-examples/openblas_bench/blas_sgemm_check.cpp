// Test the installed BLAS ABI library by calling cblas_sgemm.
// This validates that the target BLAS library can be linked and used.

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>

#include <cblas.h>

namespace {

float value_for(int row, int col, int rows) {
  return static_cast<float>(((row + 1) * 17 + (col + 1) * 31 + rows) % 101) / 101.0f;
}

void fill_col_major(std::vector<float>& matrix, int rows, int cols) {
  for (int col = 0; col < cols; ++col) {
    for (int row = 0; row < rows; ++row) {
      matrix[row + col * rows] = value_for(row, col, rows);
    }
  }
}

std::vector<float> reference_gemm(const std::vector<float>& a, const std::vector<float>& b,
                                  int m, int n, int k, float alpha, float beta) {
  std::vector<float> c(static_cast<size_t>(m) * n, 1.0f);
  for (int col = 0; col < n; ++col) {
    for (int row = 0; row < m; ++row) {
      float acc = 0.0f;
      for (int inner = 0; inner < k; ++inner) {
        acc += a[row + inner * m] * b[inner + col * k];
      }
      c[row + col * m] = alpha * acc + beta * c[row + col * m];
    }
  }
  return c;
}

double max_abs_error(const std::vector<float>& x, const std::vector<float>& y) {
  double err = 0.0;
  for (size_t i = 0; i < x.size(); ++i) {
    err = std::max(err, std::abs(static_cast<double>(x[i]) - static_cast<double>(y[i])));
  }
  return err;
}

double checksum(const std::vector<float>& x) {
  double sum = 0.0;
  for (float v : x) sum += v;
  return sum;
}

}  // namespace

int main(int argc, char** argv) {
  int m = 512;
  int n = 512;
  int k = 512;
  int repeats = 20;

  if (argc > 1) m = std::atoi(argv[1]);
  if (argc > 2) n = std::atoi(argv[2]);
  if (argc > 3) k = std::atoi(argv[3]);
  if (argc > 4) repeats = std::atoi(argv[4]);

  if (m <= 0 || n <= 0 || k <= 0 || repeats <= 0) {
    std::cerr << "usage: " << argv[0] << " [m n k repeats]\n";
    return 2;
  }

  std::vector<float> a(static_cast<size_t>(m) * k);
  std::vector<float> b(static_cast<size_t>(k) * n);
  std::vector<float> c(static_cast<size_t>(m) * n, 1.0f);

  fill_col_major(a, m, k);
  fill_col_major(b, k, n);

  float alpha = 1.25f;
  float beta = 0.5f;
  int lda = m;
  int ldb = k;
  int ldc = m;

  const auto expected = reference_gemm(a, b, m, n, k, alpha, beta);

  cblas_sgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, m, n, k, alpha, a.data(), lda, b.data(), ldb,
              beta, c.data(), ldc);

  const double err = max_abs_error(c, expected);
  const double tolerance = 1e-3 * static_cast<double>(k);

  std::cout << std::fixed << std::setprecision(6);
  std::cout << "BLAS symbol: cblas_sgemm\n";
  std::cout << "Problem: m=" << m << ", n=" << n << ", k=" << k << ", repeats=" << repeats << '\n';
  std::cout << "Correctness max_abs_error=" << err << ", tolerance=" << tolerance << '\n';
  std::cout << "Checksum=" << checksum(c) << '\n';

  if (err > tolerance) {
    std::cerr << "BLAS cblas_sgemm result: FAIL - result mismatch\n";
    return 1;
  }

  std::fill(c.begin(), c.end(), 1.0f);
  const auto start = std::chrono::steady_clock::now();
  for (int r = 0; r < repeats; ++r) {
    cblas_sgemm(CblasColMajor, CblasNoTrans, CblasNoTrans, m, n, k, alpha, a.data(), lda, b.data(), ldb,
                beta, c.data(), ldc);
  }
  const auto end = std::chrono::steady_clock::now();
  const double seconds = std::chrono::duration<double>(end - start).count();
  const double avg_seconds = seconds / repeats;
  const double gflops = (2.0 * m * n * k * repeats) / seconds / 1.0e9;

  std::cout << "Time seconds=" << seconds << '\n';
  std::cout << "Average time per SGEMM seconds=" << avg_seconds << '\n';
  std::cout << "Approx GFLOP/s=" << gflops << '\n';
  std::cout << "BLAS cblas_sgemm result: PASS - linked OpenBLAS and computed correctly.\n";
  return 0;
}
