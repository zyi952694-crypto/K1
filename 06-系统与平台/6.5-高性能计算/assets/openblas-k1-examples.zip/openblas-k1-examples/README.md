# K1 OpenBLAS 示例资源

openblas_bench/ 保留 K3 教程原始 SGEMM 示例完整源码，可用相同 CBLAS 接口对比系统与 SpacemiT 库。appendix/ 为新增的 28 算子可复现性能套件，参数和正确性校验方法见目录内 README。

依赖：sudo apt install cmake g++ make util-linux python3 libopenblas-pthread-dev openblas-spacemit

分别进入两个项目目录，执行：

```bash
cmake -S . -B build_system -DCMAKE_BUILD_TYPE=Release
cmake --build build_system
cmake -S . -B build_spacemit -DCMAKE_BUILD_TYPE=Release -DOpenBLAS_DIR=/opt/openblas-spacemit/lib/cmake/openblas
cmake --build build_spacemit
```

主示例：

```bash
taskset -c 0 ./build_system/openblas_sgemm_check
taskset -c 0 ./build_spacemit/openblas_sgemm_check
taskset -c 0-7 ./build_system/openblas_sgemm_check
taskset -c 0-7 ./build_spacemit/openblas_sgemm_check
```

附录线程控制和性能统计口径见 appendix/README.md。请用 ldd 确认两个构建分别加载对应库，已有 LD_LIBRARY_PATH 可能影响加载选择。
