# K1 OpenBLAS 附录补充套件

K3 原文未附性能表测试源码。本程序是为 K1 验证新增的独立 C++17 套件，不声称与原表使用相同数据生成器。原文列出的 28 个 CBLAS API 均有覆盖。

- 向量长度 262144，矩阵 512×512，float/double，行主序；对称与三角矩阵取下三角，不转置、非单位对角；三角带宽 K=2。
- GEMV/GEMM/SYMV/SYMM：alpha=1、beta=0；AXPY alpha=0.125；SCAL alpha=0.9999；TRMM alpha=1。三角矩阵采用接近单位阵的小幅非对角元素，使连续原地调用保持有限值。
- 每轮重置输出，预热10次，再连续调用50次，以整段 steady_clock 时间除50；复测10轮。初始化、重置、校验均在计时区间之外。AXPY/SCAL/TBMV/TPMV/TRMV/TRMM 在同一轮预热和计时内连续原位更新，输出不在每次调用间重置；每轮结束检查所有输出值有限。独立正确性检查比较重置后一次调用的结果，不逐次校验计时循环。
- 单核：OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0；八核：两变量均为8，taskset -c 0-7。运行时打印实际配置、核心与线程数。
- 每个算子先在37规模完全比对双精度标量参考；实际规模中 Level1/2 全量比对，Level3 校验行列索引 {0,1,2,17,63,127,255,511} 的64个输出。相对缩放误差为 abs(actual-reference)/(1+abs(reference))，float 容差2e-4，double容差2e-11。
- 统一名义运算计数：ASUM/COPY/SCAL=n，AXPY/DOT/NRM2=2n，GEMV/SYMV=2n²，TRMV/TPMV=n²，TBMV=n(2K+1)-K(K+1)，GEMM/SYMM=2n³，TRMM=n³。COPY不包含浮点运算，其“GFLOP/s”仅是该统一口径的元素处理速率，不解释为实际浮点吞吐。
- CSV每轮一行，avg_ms=该轮50次平均，gflops=名义计数/时间；最终 mean 与样本 sd（ddof=1）。speedup 每轮 system_ms/spacemit_ms，improvement=(speedup-1)×100%。同序号为统计配对；两库分开顺序运行，不代表交错测量。

编译及运行：

```bash
cmake -S . -B build_system -DCMAKE_BUILD_TYPE=Release
cmake --build build_system
cmake -S . -B build_spacemit -DCMAKE_BUILD_TYPE=Release -DOpenBLAS_DIR=/opt/openblas-spacemit/lib/cmake/openblas
cmake --build build_spacemit
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0 ./build_system/blas_suite 10 10 50
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0 ./build_spacemit/blas_suite 10 10 50
OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 taskset -c 0-7 ./build_system/blas_suite 10 10 50
OPENBLAS_NUM_THREADS=8 OMP_NUM_THREADS=8 taskset -c 0-7 ./build_spacemit/blas_suite 10 10 50
```

统计输出（Python 3 标准库）：

将同一线程数下两次 `blas_suite` 标准输出分别保存为 `system.csv`、`spacemit.csv`，诊断与正确性检查信息输出到标准错误，不会混入 CSV：

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0 ./build_system/blas_suite 10 10 50 > system.csv
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 taskset -c 0 ./build_spacemit/blas_suite 10 10 50 > spacemit.csv
python3 summarize.py system.csv spacemit.csv > comparison.csv
```
