// Independent K1 appendix benchmark: 28 CBLAS APIs, double reference validation.
#include <cblas.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

template<class T> struct Blas;
#define MAKE_BLAS(T,P) \
template<> struct Blas<T> { \
static T asum(int n,const T*x){return cblas_##P##asum(n,x,1);} \
static void axpy(int n,T a,const T*x,T*y){cblas_##P##axpy(n,a,x,1,y,1);} \
static void copy(int n,const T*x,T*y){cblas_##P##copy(n,x,1,y,1);} \
static T dot(int n,const T*x,const T*y){return cblas_##P##dot(n,x,1,y,1);} \
static T nrm2(int n,const T*x){return cblas_##P##nrm2(n,x,1);} \
static void scal(int n,T a,T*x){cblas_##P##scal(n,a,x,1);} \
static void gemv(int n,const T*a,const T*x,T*y){cblas_##P##gemv(CblasRowMajor,CblasNoTrans,n,n,1,a,n,x,1,0,y,1);} \
static void symv(int n,const T*a,const T*x,T*y){cblas_##P##symv(CblasRowMajor,CblasLower,n,1,a,n,x,1,0,y,1);} \
static void tbmv(int n,int k,const T*a,T*x){cblas_##P##tbmv(CblasRowMajor,CblasLower,CblasNoTrans,CblasNonUnit,n,k,a,k+1,x,1);} \
static void tpmv(int n,const T*a,T*x){cblas_##P##tpmv(CblasRowMajor,CblasLower,CblasNoTrans,CblasNonUnit,n,a,x,1);} \
static void trmv(int n,const T*a,T*x){cblas_##P##trmv(CblasRowMajor,CblasLower,CblasNoTrans,CblasNonUnit,n,a,n,x,1);} \
static void gemm(int n,const T*a,const T*b,T*c){cblas_##P##gemm(CblasRowMajor,CblasNoTrans,CblasNoTrans,n,n,n,1,a,n,b,n,0,c,n);} \
static void symm(int n,const T*a,const T*b,T*c){cblas_##P##symm(CblasRowMajor,CblasLeft,CblasLower,n,n,1,a,n,b,n,0,c,n);} \
static void trmm(int n,const T*a,T*c){cblas_##P##trmm(CblasRowMajor,CblasLeft,CblasLower,CblasNoTrans,CblasNonUnit,n,n,1,a,n,c,n);} \
};
MAKE_BLAS(float,s)
MAKE_BLAS(double,d)

volatile double sink=0;
struct Check { double max_abs=0,max_scaled=0; size_t elements=0; };
template<class T> struct Case {
  using B=Blas<T>;
  std::string op; int n,k=2; bool is_vector; std::vector<T> a,b,x,y,z,initial,band,packed; T scalar=0;
  Case(std::string operation,int size):op(operation),n(size),is_vector(op=="asum"||op=="axpy"||op=="copy"||op=="dot"||op=="nrm2"||op=="scal"),a(is_vector?0:size_t(n)*n),b(a.size()),x(n),y(n),z(n),band(is_vector?0:size_t(n)*3),packed(is_vector?0:size_t(n)*(n+1)/2) {
    for(int i=0;i<n;i++) { x[i]=T(((i*17+3)%101-50)/64.0); y[i]=T(((i*13+7)%97-48)/64.0);
      if(!is_vector)for(int j=0;j<n;j++) { a[size_t(i)*n+j]=T((((i*17+j*31+11)%101)-50)/128.0); b[size_t(i)*n+j]=T((((i*7+j*23+19)%97)-48)/128.0); }
    }
    // Near-identity lower triangular inputs keep repeated in-place calls finite.
    if(op=="tbmv"||op=="tpmv"||op=="trmv"||op=="trmm") for(int i=0;i<n;i++)for(int j=0;j<n;j++) a[size_t(i)*n+j]=j>i?0:(i==j?T(1):T((((i*17+j*31)%17)-8)/(64.0*n*n)));
    if(!is_vector)for(int i=0;i<n;i++)for(int j=0;j<=i;j++) { packed[size_t(i)*(i+1)/2+j]=a[size_t(i)*n+j]; if(i-j<=k)band[size_t(i)*(k+1)+k+j-i]=a[size_t(i)*n+j]; }
    if(op=="gemm"||op=="symm"||op=="trmm") z=b; else z=y;
    if(op=="tbmv"||op=="tpmv"||op=="trmv") z=x;
    initial=z;
  }
  void reset(){z=initial;}
  void call(){
    if(op=="asum")scalar=B::asum(n,x.data());
    else if(op=="axpy")B::axpy(n,T(.125),x.data(),z.data());
    else if(op=="copy")B::copy(n,x.data(),z.data());
    else if(op=="dot")scalar=B::dot(n,x.data(),y.data());
    else if(op=="nrm2")scalar=B::nrm2(n,x.data());
    else if(op=="scal")B::scal(n,T(.9999),z.data());
    else if(op=="gemv")B::gemv(n,a.data(),x.data(),z.data());
    else if(op=="symv")B::symv(n,a.data(),x.data(),z.data());
    else if(op=="tbmv")B::tbmv(n,k,band.data(),z.data());
    else if(op=="tpmv")B::tpmv(n,packed.data(),z.data());
    else if(op=="trmv")B::trmv(n,a.data(),z.data());
    else if(op=="gemm")B::gemm(n,a.data(),b.data(),z.data());
    else if(op=="symm")B::symm(n,a.data(),b.data(),z.data());
    else if(op=="trmm")B::trmm(n,a.data(),z.data());
    else throw std::runtime_error("unknown operation");
  }
  double flops()const{
    if(op=="asum"||op=="copy"||op=="scal")return n;
    if(op=="axpy"||op=="dot"||op=="nrm2")return 2.0*n;
    if(op=="tbmv")return double(n)*(2*k+1)-k*(k+1);
    if(op=="trmv"||op=="tpmv")return double(n)*n;
    if(op=="gemv"||op=="symv")return 2.0*n*n;
    if(op=="trmm")return double(n)*n*n;
    return 2.0*n*n*n;
  }
  Check validate(bool exhaustive) {
    reset();call();Check c;
    auto test=[&](double actual,double expected){if(!std::isfinite(actual)||!std::isfinite(expected))throw std::runtime_error("nonfinite validation");double e=std::abs(actual-expected);c.max_abs=std::max(c.max_abs,e);c.max_scaled=std::max(c.max_scaled,e/(1+std::abs(expected)));c.elements++;};
    if(op=="asum"||op=="dot"||op=="nrm2") {double expected=0;for(int i=0;i<n;i++)expected+=op=="asum"?std::abs(double(x[i])):double(x[i])*(op=="dot"?double(y[i]):double(x[i]));if(op=="nrm2")expected=std::sqrt(expected);test(scalar,expected);}
    else if(op=="axpy"||op=="copy"||op=="scal") {for(int i=0;i<n;i++)test(z[i],op=="axpy"?double(initial[i])+.125*double(x[i]):op=="copy"?double(x[i]):double(T(.9999))*double(initial[i]));}
    else if(op=="gemm"||op=="symm"||op=="trmm") {
      std::vector<int> indices;if(exhaustive)for(int i=0;i<n;i++)indices.push_back(i);else indices={0,1,2,17,63,127,255,n-1};
      for(int i:indices)for(int j:indices){double expected=0;for(int q=0;q<n;q++){double av=op=="symm"?double(a[size_t(std::max(i,q))*n+std::min(i,q)]):op=="trmm"&&q>i?0:double(a[size_t(i)*n+q]);expected+=av*double(b[size_t(q)*n+j]);}test(z[size_t(i)*n+j],expected);}
    } else for(int i=0;i<n;i++){double expected=0;for(int j=0;j<n;j++){double av=double(a[size_t(i)*n+j]);if(op=="symv")av=double(a[size_t(std::max(i,j))*n+std::min(i,j)]);if((op=="trmv"||op=="tpmv"||op=="tbmv")&&j>i)av=0;if(op=="tbmv"&&i-j>k)av=0;expected+=av*double(x[j]);}test(z[i],expected);}
    double tol=std::is_same<T,float>::value?2e-4:2e-11;
    if(c.max_scaled>tol)throw std::runtime_error(op+" validation failed: "+std::to_string(c.max_scaled));return c;
  }
};
template<class T>void run(const std::string&op,int rounds,int warm,int repeats){
  const std::string name=std::string(std::is_same<T,float>::value?"s":"d")+op;
  int n=(op=="asum"||op=="axpy"||op=="copy"||op=="dot"||op=="nrm2"||op=="scal")?262144:512;
  Case<T> small(op,37);auto s=small.validate(true);Case<T> c(op,n);auto v=c.validate(false);
  std::cerr<<"CHECK "<<name<<" PASS small_elements="<<s.elements<<" target_elements="<<v.elements<<" max_abs="<<std::max(s.max_abs,v.max_abs)<<" max_scaled="<<std::max(s.max_scaled,v.max_scaled)<<'\n';
  for(int r=0;r<rounds;r++){c.reset();for(int w=0;w<warm;w++)c.call();auto t0=std::chrono::steady_clock::now();for(int i=0;i<repeats;i++)c.call();auto t1=std::chrono::steady_clock::now();double sec=std::chrono::duration<double>(t1-t0).count()/repeats;sink+=c.scalar+c.z[0];for(T value:c.z)if(!std::isfinite(value))throw std::runtime_error("nonfinite timed array");if(!std::isfinite(sink))throw std::runtime_error("nonfinite timed output");
    std::cout<<name<<','<<n<<','<<r<<','<<sec*1000<<','<<c.flops()/sec/1e9<<','<<std::max(s.max_abs,v.max_abs)<<','<<std::max(s.max_scaled,v.max_scaled)<<'\n'<<std::flush;
  }
}
int main(int argc,char**argv){try{int rounds=argc>1?std::atoi(argv[1]):10,warm=argc>2?std::atoi(argv[2]):10,repeats=argc>3?std::atoi(argv[3]):50;if(rounds<1||warm<0||repeats<1)return 2;
std::cerr<<"CONFIG "<<openblas_get_config()<<"\nCORE "<<openblas_get_corename()<<"\nTHREADS "<<openblas_get_num_threads()<<"\nPARAM rounds="<<rounds<<" warm="<<warm<<" repeats="<<repeats<<" matrix_n=512 vector_n=262144 band_k=2 row_major lower no_trans non_unit\n";
std::cout<<std::setprecision(12)<<"function,n,round,avg_ms,gflops,max_abs_error,max_scaled_error\n";
for(const std::string op:{"asum","axpy","copy","dot","nrm2","scal","gemv","symv","tbmv","tpmv","trmv","gemm","symm","trmm"}){run<float>(op,rounds,warm,repeats);run<double>(op,rounds,warm,repeats);}return 0;}catch(const std::exception&e){std::cerr<<"FAIL "<<e.what()<<'\n';return 1;}}
