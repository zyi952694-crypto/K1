#!/usr/bin/env python3
"""Compare two blas_suite CSV outputs; Python 3 standard library only."""
import argparse
import csv
import math
import statistics
import sys

def read(path):
    groups = {}
    with open(path, newline='') as f:
        for row in csv.DictReader(f):
            key = row['function']
            trial = int(row['round'])
            values = float(row['avg_ms']), float(row['gflops'])
            if not all(math.isfinite(v) and v > 0 for v in values):
                raise ValueError(f'Invalid timing in {path}: {key}/{trial}')
            if trial in groups.setdefault(key, {}):
                raise ValueError(f'Duplicate round in {path}: {key}/{trial}')
            groups[key][trial] = values
    return groups

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('system_csv')
    parser.add_argument('spacemit_csv')
    args = parser.parse_args()
    a, b = read(args.system_csv), read(args.spacemit_csv)
    if a.keys() != b.keys() or not a:
        raise ValueError('Both files must contain the same functions')
    writer = csv.writer(sys.stdout)
    writer.writerow(['function', 'rounds', 'system_ms_mean', 'system_ms_sd',
                     'spacemit_ms_mean', 'spacemit_ms_sd',
                     'system_gflops_mean', 'system_gflops_sd',
                     'spacemit_gflops_mean', 'spacemit_gflops_sd',
                     'speedup_mean', 'speedup_sd',
                     'improvement_percent_mean', 'improvement_percent_sd'])
    for fn in a:
        trials = sorted(a[fn])
        if a[fn].keys() != b[fn].keys() or len(trials) < 2:
            raise ValueError(f'Matching rounds (at least 2) required for {fn}')
        speedups = [a[fn][r][0] / b[fn][r][0] for r in trials]
        fields = [fn, len(trials)]
        groups = [[a[fn][r][0] for r in trials], [b[fn][r][0] for r in trials],
                  [a[fn][r][1] for r in trials], [b[fn][r][1] for r in trials],
                  speedups, [(x - 1) * 100 for x in speedups]]
        for values in groups:
            fields.extend((statistics.mean(values), statistics.stdev(values)))
        writer.writerow(fields)

if __name__ == '__main__':
    main()
