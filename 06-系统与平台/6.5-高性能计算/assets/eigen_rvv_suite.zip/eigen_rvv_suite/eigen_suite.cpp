#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <functional>
#include <cstdint>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>
#ifdef _OPENMP
#include <omp.h>
#endif
#ifndef SUITE_VARIANT
#define SUITE_VARIANT "unknown"
#endif
#ifdef EIGEN_USE_BLAS
extern "C" { void openblas_set_num_threads(int); int openblas_get_num_threads(); const char* openblas_get_config(); }
#endif
using Clock = std::chrono::steady_clock;
std::string eigen_version() {
#ifdef EIGEN_VERSION_STRING
 return EIGEN_VERSION_STRING;
#else
 return std::to_string(EIGEN_WORLD_VERSION)+"."+std::to_string(EIGEN_MAJOR_VERSION)+"."+std::to_string(EIGEN_MINOR_VERSION);
#endif
}
inline void barrier(const void* p) { asm volatile("" : : "g"(p) : "memory"); }
struct Check {
  double max_abs=0, max_scaled=0;
  void add(double got,double ref,double atol,double rtol) {
    const double d=std::abs(got-ref), scale=atol+rtol*std::abs(ref);
    if(!std::isfinite(got)||!std::isfinite(ref)) {max_abs=INFINITY;max_scaled=INFINITY;return;}
    max_abs=std::max(max_abs,d);max_scaled=std::max(max_scaled,d/scale);
  }
  bool pass() const {return max_scaled<=1;}
};
struct Case {
 std::string module,name,api,dtype,input,output,params,method;
 double ops=0; int batch=1;
 std::function<void()> run;
 std::function<Check()> check;
};
template<class T> using Mat=Eigen::Matrix<T,Eigen::Dynamic,Eigen::Dynamic>;
template<class T> using Vec=Eigen::Matrix<T,Eigen::Dynamic,1>;
template<class T> std::string dtype(){return std::is_same<T,float>::value?"float32":"float64";}
template<class T> double atol(){return std::is_same<T,float>::value?4e-6:2e-12;}
template<class T> double rtol(){return std::is_same<T,float>::value?4e-5:2e-11;}
template<class T> double reduce_tol(){return std::is_same<T,float>::value?5e-4:2e-11;}
template<class T> struct ArrayState {
 Vec<T> a,b,c,y,sum_input; T scalar_result=0;
 ArrayState():a(262144),b(262144),c(262144),y(262144),sum_input(262144){
  for(int i=0;i<a.size();++i){a[i]=T(256+(i*73+19)%1024)/T(1024);b[i]=T(256+(i*151+47)%1024)/T(1024);c[i]=T((i*199+83)%1024-512)/T(1024);sum_input[i]=T(4+(i*73+19)%16)/T(16);}
 }
};
template<class T> void arrays(std::vector<Case>& out) {
 auto p=std::make_shared<ArrayState<T>>(); const int N=262144;
 const std::vector<std::string> names={"abs","add_scalar","add_vector","clamp","cos","div_scalar","div_vector","dot","exp","fma","log","max","min","mul_scalar","mul_vector","norm","normalize","segment","select","sin","sqrt","sub_scalar","sub_vector","sum","tanh"};
 const std::vector<std::string> apis={"abs(a-s)","a+s","a+b","a.max(lo).min(hi)","cos(a)","a/s","a/(b+s)","a.dot(b)","exp(a*s)","a*b+c","log(a+s)","max(a;b)","min(a;b)","a*s","a*b","a.norm()","a.normalized()","a.segment(start;length)","(a>b).select(a;b)","sin(a)","sqrt(a+s)","a-s","a-b","a.sum()","tanh(a*s)"};
 for(int k=0;k<25;++k){
  bool scalar=k==7||k==15||k==23; int len=k==17?N/2:N;
  Case cs{"array","vector_"+names[k],apis[k],dtype<T>(),"262144x1",scalar?"1x1":k==17?"131072x1":"262144x1","s=1.5;lo=0.5;hi=1.0;segment_start=65536;mask=a>b","full_scalar_reference",double(N),1};
  if(k==23){cs.api="sum_input.sum()";cs.params="sum_input[i]=(4+(i*73+19)%16)/16;grid=1/16;nonnegative;exact_partial_sums";cs.method="full_scalar_reference_exact_grid";}
  if(k==0||k==3||k==6||k==8||k==9||k==10||k==20||k==24)cs.ops=2.*N;
  if(k==7||k==15)cs.ops=2.*N;
  if(k==16)cs.ops=3.*N;
  if(k==17)cs.ops=0;
  cs.run=[p,k,N](){auto& a=p->a;auto& b=p->b;auto& c=p->c;auto& y=p->y;const T s=T(1.5);barrier(a.data());
   switch(k){
   case 0:y.array()=(a.array()-s).abs();break;
   case 1:y.array()=a.array()+s;break;
   case 2:y=a+b;break;
   case 3:y.array()=a.array().max(T(.5)).min(T(1));break;
   case 4:y.array()=a.array().cos();break;
   case 5:y.array()=a.array()/s;break;
   case 6:y.array()=a.array()/(b.array()+s);break;
   case 7:p->scalar_result=a.dot(b);break;
   case 8:y.array()=(a.array()*s).exp();break;
   case 9:y.array()=a.array()*b.array()+c.array();break;
   case 10:y.array()=(a.array()+s).log();break;
   case 11:y.array()=a.array().max(b.array());break;
   case 12:y.array()=a.array().min(b.array());break;
   case 13:y=a*s;break;
   case 14:y.array()=a.array()*b.array();break;
   case 15:p->scalar_result=a.norm();break;
   case 16:y=a.normalized();break;
   case 17:y.head(N/2)=a.segment(N/4,N/2);break;
   case 18:y.array()=(a.array()>b.array()).select(a.array(),b.array());break;
   case 19:y.array()=a.array().sin();break;
   case 20:y.array()=(a.array()+s).sqrt();break;
   case 21:y.array()=a.array()-s;break;
   case 22:y=a-b;break;
   case 23:barrier(p->sum_input.data());p->scalar_result=p->sum_input.sum();break;
   case 24:y.array()=(a.array()*s).tanh();break;
   }barrier(y.data());barrier(&p->scalar_result);
  };
  cs.check=[p,k,N,len,scalar](){Check ch;double red=0;
   if(k==7||k==15||k==16||k==23)for(int i=0;i<N;++i){double a=p->a[i];red+=k==7?a*double(p->b[i]):k==23?double(p->sum_input[i]):a*a;}
   if(k==15||k==16)red=std::sqrt(red);
   if(scalar){ch.add(p->scalar_result,red,k==23?1e-12:atol<T>(),k==23?0.:reduce_tol<T>());return ch;}
   for(int i=0;i<len;++i){double a=p->a[i],b=p->b[i],c=p->c[i],r=0,s=1.5;
    switch(k){case 0:r=std::abs(a-s);break;case 1:r=a+s;break;case 2:r=a+b;break;case 3:r=std::min(std::max(a,.5),1.);break;case 4:r=std::cos(a);break;case 5:r=a/s;break;case 6:r=a/(b+s);break;case 8:r=std::exp(a*s);break;case 9:r=a*b+c;break;case 10:r=std::log(a+s);break;case 11:r=std::max(a,b);break;case 12:r=std::min(a,b);break;case 13:r=a*s;break;case 14:r=a*b;break;case 16:r=a/red;break;case 17:r=p->a[i+N/4];break;case 18:r=a>b?a:b;break;case 19:r=std::sin(a);break;case 20:r=std::sqrt(a+s);break;case 21:r=a-s;break;case 22:r=a-b;break;case 24:r=std::tanh(a*s);break;}
    ch.add(p->y[i],r,atol<T>(),k==16?reduce_tol<T>():rtol<T>());
   }return ch;
  };out.push_back(std::move(cs));
 }
}
template<class T> struct GeoState {Eigen::Quaternion<T> q,qn,qi;Eigen::Matrix<T,3,1> a,b,c;Eigen::Matrix<T,3,3> R;GeoState():q(T(.75),T(.125),T(-.25),T(.5)),qn(q),qi(q),a(T(.25),T(-.5),T(.75)),b(T(.5),T(.25),T(-.125)) {q.normalize();}};
template<class T> void geometry(std::vector<Case>& out){
 auto p=std::make_shared<GeoState<T>>();
 const char* names[]={"quaternion_inverse","quaternion_normalize","quaternion_to_rotation_matrix","vector_cross"};
 const char* apis[]={"Quaternion::inverse()","Quaternion::normalized()","Quaternion::toRotationMatrix()","a.cross(b)"};
 for(int k=0;k<4;++k){Case cs{"geometry",names[k],apis[k],dtype<T>(),k==3?"3x1":"4x1",k==2?"3x3":k==3?"3x1":"4x1","q_normalized_input;inner_batch=1024","scalar_formula",k==2?30.:k==3?9.:k==1?12.:11.,1024};
 cs.run=[p,k](){barrier(p->q.coeffs().data());barrier(p->a.data());switch(k){case 0:p->qi=p->q.inverse();barrier(p->qi.coeffs().data());break;case 1:p->qn=p->q.normalized();barrier(p->qn.coeffs().data());break;case 2:p->R=p->q.toRotationMatrix();barrier(p->R.data());break;case 3:p->c=p->a.cross(p->b);barrier(p->c.data());break;}};
 cs.check=[p,k](){Check ch;double x=p->q.x(),y=p->q.y(),z=p->q.z(),w=p->q.w(),n=x*x+y*y+z*z+w*w;
 if(k==0||k==1)for(int j=0;j<4;++j){double v=p->q.coeffs()[j];double r=k==0?(j==3?v:-v)/n:v/std::sqrt(n);ch.add(k==0?p->qi.coeffs()[j]:p->qn.coeffs()[j],r,atol<T>(),rtol<T>());}
 if(k==2){double r[3][3]={{1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w)},{2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w)},{2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)}};for(int i=0;i<3;++i)for(int j=0;j<3;++j)ch.add(p->R(i,j),r[i][j],atol<T>(),rtol<T>());}
 if(k==3)for(int j=0;j<3;++j){int a=(j+1)%3,b=(j+2)%3;ch.add(p->c[j],double(p->a[a])*p->b[b]-double(p->a[b])*p->b[a],atol<T>(),rtol<T>());}return ch;};out.push_back(std::move(cs));}
}
template<class T> struct MatrixState {
 Mat<T>A,B,C,P,block; Vec<T>x,y,u,rhs; Eigen::Matrix<T,1,Eigen::Dynamic>row;Eigen::LLT<Mat<T>>llt;Eigen::LDLT<Mat<T>>ldlt;T scalar_result=0;double u2=0;
 MatrixState():A(512,512),B(512,512),C(512,512),P(512,512),block(256,256),x(512),y(512),u(512),rhs(512),row(512){
  for(int i=0;i<512;++i){x[i]=T((i*41+17)%1024-512)/T(1024);u[i]=T(4+(i*13+3)%17)/T(1024);u2+=double(u[i])*double(u[i]);}
  for(int j=0;j<512;++j)for(int i=0;i<512;++i){uint32_t z=uint32_t(i+j*512);auto hash=[](uint32_t q){q^=q>>16;q*=0x7feb352dU;q^=q>>15;q*=0x846ca68bU;q^=q>>16;return q;};A(i,j)=T(int(hash(z+20261020U)%1024)-512)/T(1024);B(i,j)=T(int(hash(z+901985U)%1024)-512)/T(1024);P(i,j)=(i==j?T(1):T(0))+u[i]*u[j];}
  for(int i=0;i<512;++i){double v=0;for(int j=0;j<512;++j)v+=double(P(i,j))*double(x[j]);rhs[i]=T(v);}llt.compute(P);ldlt.compute(P);
  if(llt.info()!=Eigen::Success||ldlt.info()!=Eigen::Success)throw std::runtime_error("SPD decomposition failed");
 }
};
template<class T> void matrices(std::vector<Case>& out){auto p=std::make_shared<MatrixState<T>>();const int N=512;
 const char* names[]={"add","block","colwise_sum","cwise_product","determinant","gemv","identity","inverse","ldlt_solve","llt_solve","matmul","rowwise_sum","sub","trace","transpose","zero"};
 const char* apis[]={"A+B","A.block(128;128;256;256)","A.colwise().sum()","A.cwiseProduct(B)","P.determinant()","A*x","Identity()","P.inverse()","LDLT::solve(rhs)","LLT::solve(rhs)","A*B","A.rowwise().sum()","A-B","A.trace()","A.transpose()","Zero()"};
 const char* outputs[]={"512x512","256x256","1x512","512x512","1x1","512x1","512x512","512x512","512x1","512x1","512x512","512x1","512x512","1x1","512x512","512x512"};
 for(int k=0;k<16;++k){double ops=double(N)*N;
 if(k==1||k==6||k==14||k==15)ops=0;if(k==4)ops=2.*N*N*N/3;if(k==5||k==8||k==9)ops=2.*N*N;if(k==7)ops=2.*N*N*N;if(k==10)ops=2.*N*N*N;if(k==13)ops=N;
 Case cs{"matrix","matrix_"+std::string(names[k]),apis[k],dtype<T>(),k==6||k==15?"1x1":"512x512",outputs[k],"column_major;N=512;block_start=128;SPD=I+u*uT;decomposition_outside_solve_timing",k==10?"65_scalar_entries_and_2_full_projections":k==7||k==4?"rank_one_analytic_reference":k==8||k==9?"known_solution_and_full_residual":"full_scalar_reference",ops,1};
 cs.run=[p,k](){barrier(p->A.data());barrier(p->P.data());switch(k){case 0:p->C=p->A+p->B;break;case 1:p->block=p->A.block(128,128,256,256);break;case 2:p->row=p->A.colwise().sum();break;case 3:p->C=p->A.cwiseProduct(p->B);break;case 4:p->scalar_result=p->P.determinant();break;case 5:p->y.noalias()=p->A*p->x;break;case 6:p->C.setIdentity();break;case 7:p->C=p->P.inverse();break;case 8:p->y=p->ldlt.solve(p->rhs);break;case 9:p->y=p->llt.solve(p->rhs);break;case 10:p->C.noalias()=p->A*p->B;break;case 11:p->y=p->A.rowwise().sum();break;case 12:p->C=p->A-p->B;break;case 13:p->scalar_result=p->A.trace();break;case 14:p->C=p->A.transpose();break;case 15:p->C.setZero();break;}barrier(p->C.data());barrier(p->block.data());barrier(p->row.data());barrier(p->y.data());barrier(&p->scalar_result);};
 cs.check=[p,k,N](){Check ch;
 if(k==4){ch.add(p->scalar_result,1+p->u2,atol<T>(),std::is_same<T,float>::value?2e-3:2e-10);return ch;}
 if(k==13){double r=0;for(int i=0;i<N;++i)r+=p->A(i,i);ch.add(p->scalar_result,r,atol<T>(),reduce_tol<T>());return ch;}
 if(k==10){for(int t=0;t<65;++t){int i=(t*193+17)%N,j=(t*137+23)%N;double r=0;for(int z=0;z<N;++z)r+=double(p->A(i,z))*double(p->B(z,j));ch.add(p->C(i,j),r,atol<T>()*N,rtol<T>());}
  for(int seed=0;seed<2;++seed){std::vector<double> v(N),bv(N);for(int j=0;j<N;++j)v[j]=double((j*41+seed*37+19)%31-15)/16;for(int i=0;i<N;++i)for(int j=0;j<N;++j)bv[i]+=double(p->B(i,j))*v[j];for(int i=0;i<N;++i){double got=0,ref=0;for(int j=0;j<N;++j){got+=double(p->C(i,j))*v[j];ref+=double(p->A(i,j))*bv[j];}ch.add(got,ref,atol<T>()*N,rtol<T>()*4);}}return ch;}
 if(k==5||k==8||k==9||k==11){for(int i=0;i<N;++i){double r=0;if(k==5)for(int j=0;j<N;++j)r+=double(p->A(i,j))*p->x[j];if(k==11)for(int j=0;j<N;++j)r+=p->A(i,j);if(k==8||k==9){r=p->x[i];double residual=0;for(int j=0;j<N;++j)residual+=double(p->P(i,j))*p->y[j];ch.add(residual,p->rhs[i],atol<T>()*8,rtol<T>()*8);}ch.add(p->y[i],r,atol<T>()*8,rtol<T>()*8);}return ch;}
 if(k==2){for(int j=0;j<N;++j){double r=0;for(int i=0;i<N;++i)r+=p->A(i,j);ch.add(p->row[j],r,atol<T>()*N,reduce_tol<T>());}return ch;}
 const int M=k==1?256:N;for(int j=0;j<M;++j)for(int i=0;i<M;++i){double r=0,g=k==1?p->block(i,j):p->C(i,j);switch(k){case 0:r=double(p->A(i,j))+p->B(i,j);break;case 1:r=p->A(i+128,j+128);break;case 3:r=double(p->A(i,j))*p->B(i,j);break;case 6:r=i==j?1:0;break;case 7:r=(i==j?1.:0.)-double(p->u[i])*double(p->u[j])/(1+p->u2);break;case 12:r=double(p->A(i,j))-p->B(i,j);break;case 14:r=p->A(j,i);break;case 15:r=0;break;}ch.add(g,r,atol<T>(),rtol<T>());}return ch;
 };out.push_back(std::move(cs));}
}
int main(int argc,char**argv){try{
 int threads=1,iterations=50,rounds=10,warmup=10,round_start=1;bool verify_only=false,list=false;std::string filter;
 for(int i=1;i<argc;++i){std::string a=argv[i];if(a=="--verify-only")verify_only=true;else if(a=="--list")list=true;else if(i+1<argc){std::string v=argv[++i];if(a=="--threads")threads=std::stoi(v);else if(a=="--iterations")iterations=std::stoi(v);else if(a=="--rounds")rounds=std::stoi(v);else if(a=="--round-start")round_start=std::stoi(v);else if(a=="--warmup")warmup=std::stoi(v);else if(a=="--filter")filter=v;else throw std::runtime_error("unknown option");}else throw std::runtime_error("missing value");}
 if(threads<1||iterations<1||rounds<1||warmup<0)throw std::runtime_error("invalid count");Eigen::setNbThreads(threads);
#ifdef _OPENMP
 omp_set_dynamic(0);omp_set_num_threads(threads);
#endif
#ifdef EIGEN_USE_BLAS
 openblas_set_num_threads(threads);
 std::cerr<<"openblas_threads="<<openblas_get_num_threads()<<" openblas_config="<<openblas_get_config()<<'\n';
#endif
 std::cerr<<"variant="<<SUITE_VARIANT<<" eigen="<<eigen_version()<<" simd="<<Eigen::SimdInstructionSetsInUse()<<" eigen_threads="<<Eigen::nbThreads()<<" requested_threads="<<threads<<'\n';
#ifdef EIGEN_VECTORIZE_RVV10
 std::cerr<<" EIGEN_VECTORIZE_RVV10=defined\n";
#else
 std::cerr<<" EIGEN_VECTORIZE_RVV10=not_defined\n";
#endif
 std::vector<Case> cases;arrays<float>(cases);arrays<double>(cases);geometry<float>(cases);geometry<double>(cases);matrices<float>(cases);matrices<double>(cases);
 std::cout<<"variant,threads,module,function,dtype,input_size,output_size,round,iterations,warmup,inner_batch,avg_ms,estimated_gflops,check_pass,max_abs_error,max_scaled_error,check_method,api,parameters\n"<<std::setprecision(12);
 int failed=0,covered=0;for(auto& c:cases){if(!filter.empty()&&c.name.find(filter)==std::string::npos)continue;++covered;
 if(list){std::cout<<SUITE_VARIANT<<','<<threads<<','<<c.module<<','<<c.name<<','<<c.dtype<<','<<c.input<<','<<c.output<<",0,0,0,"<<c.batch<<",0,0,1,0,0,"<<c.method<<','<<c.api<<','<<c.params<<'\n';continue;}
 c.run();Check check=c.check();if(!check.pass()){++failed;std::cerr<<"CHECK_FAIL "<<c.name<<' '<<c.dtype<<" abs="<<check.max_abs<<" scaled="<<check.max_scaled<<'\n';}
 int count=verify_only?1:rounds;for(int round=1;round<=count;++round){double avg=0;if(!verify_only){for(int w=0;w<warmup;++w)for(int b=0;b<c.batch;++b)c.run();auto t=Clock::now();for(int it=0;it<iterations;++it)for(int b=0;b<c.batch;++b)c.run();avg=std::chrono::duration<double,std::milli>(Clock::now()-t).count()/(double(iterations)*c.batch);check=c.check();if(!check.pass())++failed;}
 std::cout<<SUITE_VARIANT<<','<<threads<<','<<c.module<<','<<c.name<<','<<c.dtype<<','<<c.input<<','<<c.output<<','<<(round_start+round-1)<<','<<(verify_only?0:iterations)<<','<<(verify_only?0:warmup)<<','<<c.batch<<','<<avg<<','<<(avg>0?c.ops/avg/1e6:0)<<','<<check.pass()<<','<<check.max_abs<<','<<check.max_scaled<<','<<c.method<<','<<c.api<<','<<c.params<<'\n'<<std::flush;}
 std::cerr<<"DONE "<<c.name<<' '<<c.dtype<<" check="<<check.pass()<<'\n';}
 if(covered==0)throw std::runtime_error("no cases match filter");
 std::cerr<<"covered="<<covered<<" failures="<<failed<<'\n';return failed?2:0;
}catch(const std::exception&e){std::cerr<<"error="<<e.what()<<'\n';return 1;}}
