#!/usr/bin/env python3
"""Aggregate original per-round means; sample SD, paired ratios by round id."""
import csv
import json
import math
import statistics as st
import sys
from pathlib import Path

def main():
    folder=Path(sys.argv[1] if len(sys.argv)>1 else '../results')
    records=[]
    for file in sorted(folder.glob('round*_t*.csv')):
        round_id=int(file.name.split('_')[0][5:])
        with file.open() as fh:
            for row in csv.DictReader(fh):
                row['round']=round_id
                for key in ['threads','iterations','warmup','inner_batch','check_pass']: row[key]=int(row[key])
                for key in ['avg_ms','estimated_gflops','max_abs_error','max_scaled_error']:row[key]=float(row[key])
                row['source_file']=file.name
                records.append(row)
    if not records: raise SystemExit('No round CSV files')
    case_folder=folder/'raw_by_case'
    case_folder.mkdir(exist_ok=True)
    by_case={}
    for row in records: by_case.setdefault((row['function'],row['dtype']),[]).append(row)
    for (function,dtype), rows in by_case.items():
        with (case_folder/f'{function}_{dtype}.csv').open('w') as fh:
            w=csv.DictWriter(fh,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    groups={}
    for row in records: groups.setdefault((row['variant'],row['threads'],row['function'],row['dtype']),[]).append(row)
    summary=[]
    for key, rows in sorted(groups.items()):
        assert len({x['round'] for x in rows})==len(rows),'Duplicate rounds'
        assert all(math.isfinite(x['avg_ms']) and x['avg_ms']>0 for x in rows),'Invalid time'
        r={k:rows[0][k] for k in ['variant','threads','module','function','dtype','input_size','output_size','inner_batch','check_method','api','parameters']}
        r.update(rounds=len(rows),iterations_per_round=rows[0]['iterations'],warmup_per_round=rows[0]['warmup'],all_checks_pass=all(x['check_pass']==1 for x in rows),max_scaled_error=max(x['max_scaled_error'] for x in rows))
        for field in ['avg_ms','estimated_gflops']:
            vals=[x[field] for x in rows];r[field+'_mean']=st.mean(vals);r[field+'_sd']=st.stdev(vals) if len(vals)>1 else 0.
        summary.append(r)
    with (folder/'summary.csv').open('w') as fh:
        w=csv.DictWriter(fh,fieldnames=list(summary[0]));w.writeheader();w.writerows(summary)
    comparisons=[]
    for base,target in [('system','vendor'),('vendor','vendor_blas')]:
        for (variant,threads,function,dtype),rows in sorted(groups.items()):
            if variant!=base:continue
            others={x['round']:x for x in groups.get((target,threads,function,dtype),[])}
            pairs=[(x,others[x['round']]) for x in rows if x['round'] in others]
            if not pairs:continue
            speedups=[a['avg_ms']/b['avg_ms'] for a,b in pairs]
            comparison={'baseline':base,'target':target,'threads':threads,'function':function,'dtype':dtype,'paired_rounds':len(pairs),'speedup_mean':st.mean(speedups),'speedup_sd':st.stdev(speedups) if len(speedups)>1 else 0.}
            comparison['improvement_percent_mean']=(comparison['speedup_mean']-1)*100
            comparison['improvement_percent_sd']=comparison['speedup_sd']*100
            comparisons.append(comparison)
    if comparisons:
        with (folder/'comparisons.csv').open('w') as fh:
            w=csv.DictWriter(fh,fieldnames=list(comparisons[0]));w.writeheader();w.writerows(comparisons)
    coverage={'expected_conditions':9,'expected_cases_per_condition':90,'expected_rounds':10,'expected_timing_rows':8100,'observed_timing_rows':len(records),'observed_case_conditions':len(groups),'all_checks_pass':all(x['check_pass']==1 for x in records),'complete':len(groups)==810 and all(len(x)==10 for x in groups.values()),'round_counts':{f'{variant}:t{threads}': sorted(set(len(v) for k,v in groups.items() if k[:2]==(variant,threads))) for variant in ['system','vendor','vendor_blas'] for threads in [1,4,8]}}
    expected=json.loads((Path(__file__).parent/'expected_cases.json').read_text())
    expected_groups={(variant,threads,r['function'],r['dtype']) for variant in ['system','vendor','vendor_blas'] for threads in [1,4,8] for r in expected}
    coverage['missing_case_conditions']=[list(k) for k in sorted(expected_groups-set(groups))]
    coverage['unexpected_case_conditions']=[list(k) for k in sorted(set(groups)-expected_groups)]
    coverage['complete']=coverage['complete'] and set(groups)==expected_groups and all({x['round'] for x in values}==set(range(1,11)) for values in groups.values())
    (folder/'coverage.json').write_text(json.dumps(coverage,indent=2)+'\n')
    print(json.dumps(coverage,indent=2))
if __name__=='__main__':main()
