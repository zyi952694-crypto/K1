# K1 Eigen 独立复现套件

本套件用于在 K1 测试 45 个算子、float32/float64 两种类型，共 90 个组合。输入、计时范围和正确性检查方法见下文。系统与厂商 Eigen 的版本和实现不同，数据反映两套构建的整体差异。

## 构建与运行

依赖 GCC 14、libeigen3-dev、eigen-spacemit、openblas-spacemit、util-linux、Python 3。三种构建都用 `-O3 -DNDEBUG -std=c++17 -fopenmp`；不使用 `-ffast-math`。

- system：`/usr/include/eigen3`，`-march=rv64gc -mabi=lp64d`。
- vendor：`/opt/eigen-spacemit/include/eigen3`，`-march=rv64gcv_zvl256b -mabi=lp64d -mrvv-vector-bits=zvl -DEIGEN_RISCV64_USE_RVV10`。
- vendor_blas：在 vendor 基础上增加 `-DEIGEN_USE_BLAS`，显式链接 `/opt/openblas-spacemit/lib/libopenblas.so`，写入该路径的 rpath。

```bash
bash build.sh
bash run.sh verify
bash run.sh quick
bash run.sh full
python3 summarize.py ../results
```

编译和每次完整案例组执行都会通过 `flock /tmp/k1-rvv-validation.lock` 串行，防止其他章节的编译/计时干扰。每个进程结束释放锁。`run.sh` 检查并跳过已完整通过的同名90行结果，便于中断后继续；遇到不完整同名结果则停止，避免覆盖证据。

CPU 亲和性分别为 0、0–3、0–7，对应线程数 1、4、8。同时设置 `Eigen::setNbThreads`、OpenMP 线程数以及 BLAS 构建的 `openblas_set_num_threads`；日志分别输出 Eigen 和 OpenBLAS 的实际线程配置。线程设置不代表每个 Eigen 算子均支持并行。

`condition.sh` 在获得锁后、每个条件执行开始与结束时记录 CPU 调速策略、当前/最高频率配置及可读温度传感器。频率与温度是端点采样，不能证明计时期间恒频。

Eigen 5 的版本号用 `EIGEN_VERSION_STRING`；旧系统 Eigen 回退到 WORLD.MAJOR.MINOR。厂商的 `SimdInstructionSetsInUse()` 辅助函数可能输出 None，不能据此判断 RVV10 是否启用，日志另外输出 `EIGEN_VECTORIZE_RVV10`。

## 参数和计时边界

- 数组长度 262144，列主序矩阵 512×512；两种类型使用相同确定性输入。没有外部文件或随机设备输入。
- 数组 a、b 为 `[0.25, 1.25)` 的二进制可精确表示数，c 为 `[-0.5, 0.5)`；索引整数公式在源码中完整定义。scalar=1.5，clamp 下/上界=0.5/1.0，select 掩码=a>b。
- sum 独立使用 `sum_input[i]=(4+(i*73+19)%16)/16`，长度仍为262144，范围 `[0.25,1.1875]`。输入非负且为1/16网格，任意部分和乘16为小于2^24的整数，float32/float64任意归约顺序均可精确表示；总和为188416。因此sum专门使用atol=1e-12、rtol=0检查，float32任一ULP误差均会检出。
- segment 起点 65536、长度 131072；block 起点 `(128,128)`、大小256×256。复制操作将表达式实质化到已分配输出。
- 矩阵 A、B 使用固定整数哈希种子 20261020、901985 产生 `[-0.5,0.5)` 的元素，避免低秩或重复列。向量 x 使用固定整数公式。
- 求逆、行列式、LLT 和 LDLT 使用 `P=I+u*uᵀ`。u 的值为 `[4,20]/1024`，P 的谱条件数为 `1+uᵀu`，小于 1.2；乘积和对角元素在两种类型中均精确可表示。此条件良好的稠密矩阵提供独立解析参考，避免行列式溢出。它不代表所有矩阵条件数。
- LLT、LDLT 只计时 `solve(rhs)`，分解在计时之外；rhs 从已知解 x 构造。inverse 和 determinant 包含各自的内部矩阵分解。
- 几何操作使用固定非零向量及单位四元数。四元数实际是 4 个系数，因此输入为4×1，inverse/normalize输出也为4×1；纠正 K3 表中写成3×1的尺寸，旋转矩阵输出仍为3×3。normalize 采用 normalized() 实质化输出，确保每次用相同原始输入。
- 每个算子每轮预热 10 次、计时 50 次，共独立执行10轮。几何小算子的每次迭代含1024个相同操作，耗时除以1024，避免计时器分辨率主导结果。其余算子的 inner_batch=1。
- 数据准备、空间分配（算法内部所需分配除外）、参考结果计算、正确性比较、CSV和日志写入均在计时之外。每次调用在输入与输出设置编译器内存屏障，防止编译器消除或移出循环；测量包含调用和屏障开销。
- 使用 steady_clock；每轮原始记录保存总计时除以50与inner_batch的平均毫秒数。mean为10个轮平均值的平均，sd为样本标准差（ddof=1）。speedup为同轮基准/目标耗时的比值，再计算10轮均值和样本标准差；improvement=(speedup−1)×100%。
- `estimated_gflops` 仅为源码明确的理论操作数除以时间。超越函数按一次操作计数，比较/选择也按约定计数，因此它不是硬件实际浮点指令吞吐。复制/转置/构造的计数为0；评估性能优先使用毫秒数。

## 正确性检查

每个案例在预热前、每轮计时结束后检查输出，CSV 保存 pass、最大绝对误差、最大容差比例以及检查方法。任何失败进程返回2，运行脚本停止；非有限输出视为失败。

- 数组逐元素使用 C++ 标量公式、标准库数学函数计算完整参考；归约使用 double 累加，与被测 Eigen 实现独立。
- 基本矩阵运算遍历全部元素对比标量参考，gemv比较全部512个结果。
- matmul 对65个固定位置计算标量点积，并用两组确定性向量检查全部512个输出投影 `C*v = A*(B*v)`；属于有明确覆盖范围的数值检查，不是所有矩阵输入的证明。
- determinant 对比 `1+uᵀu`；inverse 对比完整解析矩阵 `I−u*uᵀ/(1+uᵀu)`。
- LLT/LDLT 对比完整已知解，并用标量循环检查全部方程残差。
- 几何操作使用四元数/旋转矩阵/叉积的标量解析公式比较全部输出。

逐元素容差规则为 `abs(got-ref) <= atol + rtol*abs(ref)`：float32 的基础 atol=4e-6、rtol=4e-5；float64 为2e-12、2e-11。大规模归约 float32 rtol=5e-4；矩阵乘法采样绝对容差乘512，投影相对容差乘4；求解绝对/相对容差乘8；determinant 的相对容差为 float32 2e-3、float64 2e-10。各特殊规则均在源码中直接给出。容差比例不超过1为通过。

这些检查验证指定的确定性案例；业务应用仍须按自己的输入分布、条件数和精度要求验证。
