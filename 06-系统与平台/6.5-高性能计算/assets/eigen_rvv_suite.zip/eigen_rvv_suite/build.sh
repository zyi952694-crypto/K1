#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p build ../logs
for variant in system vendor vendor_blas; do
  flags=(-O3 -DNDEBUG -std=c++17 -fopenmp -mabi=lp64d -DSUITE_VARIANT=\""$variant"\")
  libs=()
  if [[ "$variant" == system ]]; then
    flags+=(-march=rv64gc -I/usr/include/eigen3)
  else
    flags+=(-march=rv64gcv_zvl256b -mrvv-vector-bits=zvl -DEIGEN_RISCV64_USE_RVV10 -I/opt/eigen-spacemit/include/eigen3)
  fi
  if [[ "$variant" == vendor_blas ]]; then
    flags+=(-DEIGEN_USE_BLAS)
    libs+=(/opt/openblas-spacemit/lib/libopenblas.so -Wl,-rpath,/opt/openblas-spacemit/lib -lpthread)
  fi
  printf '%q ' g++-14 "${flags[@]}" eigen_suite.cpp "${libs[@]}" -o "build/eigen_suite_$variant" > "../logs/suite_build_$variant.command"
  flock /tmp/k1-rvv-validation.lock g++-14 "${flags[@]}" eigen_suite.cpp "${libs[@]}" -o "build/eigen_suite_$variant" > "../logs/suite_build_$variant.log" 2>&1
  sha256sum "build/eigen_suite_$variant" > "../logs/suite_build_$variant.sha256"
done
