#!/usr/bin/env python3
"""Estimate compute time from all nine untuned quick runs; exclude lock waits."""
import csv
import json
import sys
from pathlib import Path


def main():
    folder = Path(sys.argv[1] if len(sys.argv) > 1 else '../results')
    conditions = []
    for threads in (1, 4, 8):
        for variant in ('system', 'vendor', 'vendor_blas'):
            path = folder / f'quick_{variant}_t{threads}.csv'
            with path.open() as fh:
                rows = list(csv.DictReader(fh))
            if len(rows) != 90 or any(r['check_pass'] != '1' for r in rows):
                raise SystemExit(f'Quick result incomplete or failed: {path}')
            # Geometry reports per operation after dividing by its inner batch.
            iteration_ms = sum(float(r['avg_ms']) * int(r['inner_batch']) for r in rows)
            conditions.append({
                'variant': variant, 'threads': threads,
                'quick_rows': len(rows),
                'sum_case_iteration_ms': iteration_ms,
                'projected_10_round_compute_seconds': iteration_ms * 60 * 10 / 1000,
            })
    report = {
        'method': 'sum(avg_ms * inner_batch) * (10 warmup + 50 measured) * 10 rounds',
        'excludes': ['data preparation', 'correctness checks', 'lock waits', 'process launch'],
        'note': 'Single-iteration quick timings are a rough scheduling estimate only.',
        'conditions': conditions,
        'projected_total_compute_seconds': sum(r['projected_10_round_compute_seconds'] for r in conditions),
    }
    (folder / 'quick_runtime_estimate.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
