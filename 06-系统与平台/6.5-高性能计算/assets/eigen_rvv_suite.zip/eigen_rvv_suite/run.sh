#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
mkdir -p ../logs ../results
mode=${1:-full}
run_one() {
 local variant=$1 threads=$2 tag=$3
 shift 3
 local cpus=0
 [[ "$threads" == 4 ]] && cpus=0-3
 [[ "$threads" == 8 ]] && cpus=0-7
 local target="../results/${tag}_${variant}_t${threads}.csv"
 if [[ -e "$target" ]]; then
   if python3 - "$target" "../logs/${tag}_${variant}_t${threads}.log" <<'PYRESUME'
import csv,sys
from pathlib import Path
rows=list(csv.DictReader(open(sys.argv[1])))
log=Path(sys.argv[2]).read_text() if Path(sys.argv[2]).exists() else ''
sys.exit(0 if len(rows)==90 and all(r.get('check_pass')=='1' for r in rows) and 'covered=90 failures=0' in log else 1)
PYRESUME
   then
     echo "Skipping completed $target"
     return 0
   fi
   echo "Existing incomplete result: $target; refusing to overwrite" >&2
   return 1
 fi
 echo "$(date --iso-8601=seconds) start $tag $variant threads=$threads"
 flock /tmp/k1-rvv-validation.lock bash ./condition.sh "$variant" "$threads" "$@" > "$target" 2> "../logs/${tag}_${variant}_t${threads}.log"
 echo "$(date --iso-8601=seconds) complete $tag $variant threads=$threads"
}
if [[ "$mode" == verify ]]; then
 for threads in 1 4 8; do
  for variant in system vendor vendor_blas; do run_one "$variant" "$threads" verify --verify-only; done
 done
elif [[ "$mode" == quick ]]; then
 for threads in 1 4 8; do
  for variant in system vendor vendor_blas; do run_one "$variant" "$threads" quick --rounds 1 --warmup 0 --iterations 1; done
 done
elif [[ "$mode" == full ]]; then
 for round in $(seq 1 10); do
  for threads in 1 4 8; do
   for variant in system vendor vendor_blas; do
    run_one "$variant" "$threads" "round${round}" --rounds 1 --round-start "$round" --warmup 10 --iterations 50
   done
  done
 done
else
 echo 'Usage: ./run.sh {verify|quick|full}' >&2
 exit 1
fi
