#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
variant=$1
threads=$2
shift 2
cpus=0
[[ "$threads" == 4 ]] && cpus=0-3
[[ "$threads" == 8 ]] && cpus=0-7
snapshot() {
 local phase=$1 file value
 printf 'telemetry phase=%s timestamp=%s\n' "$phase" "$(date --iso-8601=seconds)" >&2
 for file in /sys/devices/system/cpu/cpufreq/policy*/scaling_cur_freq /sys/devices/system/cpu/cpufreq/policy*/scaling_max_freq /sys/devices/system/cpu/cpufreq/policy*/scaling_governor /sys/class/thermal/thermal_zone*/type /sys/class/thermal/thermal_zone*/temp; do
  [[ -r "$file" ]] || continue
  read -r value < "$file" || value=unavailable
  printf 'telemetry phase=%s path=%s value=%s\n' "$phase" "$file" "$value" >&2
 done
}
snapshot start
set +e
env OMP_NUM_THREADS="$threads" OMP_DYNAMIC=FALSE OPENBLAS_NUM_THREADS="$threads" taskset -c "$cpus" "./build/eigen_suite_$variant" --threads "$threads" "$@"
rc=$?
set -e
snapshot end
printf 'condition_exit_code=%s\n' "$rc" >&2
exit "$rc"
