#!/usr/bin/env python3
"""Compare K3CVOUT1 dumps element by element; uses only Python's standard library."""
import argparse
import array
import csv
import math
from pathlib import Path
import re
import struct
import sys

# Engineering screening tolerances, not tolerances claimed by the original SDK.
U8_ONE = {"resize_linear", "cvtColor_bgr2gray", "gaussian_blur_3x3",
          "addWeighted_segmentation_mask", "pyrDown_pyrUp"}

def read_dump(path):
    with path.open("rb") as f:
        def exact(n):
            b = f.read(n)
            if len(b) != n:
                raise ValueError(f"Truncated dump: {path}")
            return b
        def u32():
            return struct.unpack("<I", exact(4))[0]
        if exact(8) != b"K3CVOUT1":
            raise ValueError(f"Bad dump magic: {path}")
        count = u32()
        if not 1 <= count <= 16:
            raise ValueError(f"Invalid matrix count: {path}")
        result = []
        for _ in range(count):
            mat_type, dims = u32(), u32()
            if not 1 <= dims <= 8:
                raise ValueError(f"Invalid dimension count: {path}")
            shape = tuple(u32() for _ in range(dims))
            depth, channels = mat_type & 7, (mat_type >> 3) + 1
            code = {0: "B", 5: "f", 6: "d"}.get(depth)
            if code is None:
                raise ValueError(f"Unsupported matrix type {mat_type}: {path}")
            byte_count = u32()
            expected = math.prod(shape) * channels * {0: 1, 5: 4, 6: 8}[depth]
            if byte_count != expected or byte_count > 512 * 1024 * 1024:
                raise ValueError(f"Invalid payload length: {path}")
            values = array.array(code)
            values.frombytes(exact(byte_count))
            if sys.byteorder != "little" and values.itemsize > 1:
                values.byteswap()
            result.append((mat_type, shape, values))
        if f.read(1):
            raise ValueError(f"Trailing bytes: {path}")
        return result


def tolerances(function, mat_type, strict, matrix_index):
    if strict:
        return 0.0, 0.0
    depth = mat_type & 7
    if depth == 0:
        return (1.0 if function in U8_ONE else 0.0), 0.0
    if function in {"minMaxLoc", "threshold_otsu_gray"}:
        return 0.0, 0.0
    if function == "dft":
        return 0.005, 0.0001
    if function == "dot":
        return 1e-8, 1e-6
    if function == "cartToPolar":
        # OpenCV documents approximately 0.3 degrees angle accuracy.
        # This is a cross-build screening tolerance, not an atan2 reference test.
        return (math.radians(0.3), 0.0) if matrix_index == 1 else (1e-5, 1e-5)
    return 2e-6, 2e-6


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("reference_dir", type=Path)
    p.add_argument("candidate_dir", type=Path)
    p.add_argument("--strict", action="store_true", help="Require exact numeric equality")
    args = p.parse_args()
    left = {x.name: x for x in args.reference_dir.glob("*.bin")}
    right = {x.name: x for x in args.candidate_dir.glob("*.bin")}
    if not left or left.keys() != right.keys():
        print(f"ERROR: dump sets differ or are empty; only_reference={sorted(left.keys()-right.keys())}; only_candidate={sorted(right.keys()-left.keys())}", file=sys.stderr)
        return 2
    writer = csv.writer(sys.stdout)
    writer.writerow(["case", "matrix", "elements", "atol", "rtol", "max_abs_error", "rmse", "failed_elements", "status"])
    failures = 0
    for name in sorted(left):
        reference, candidate = read_dump(left[name]), read_dump(right[name])
        if len(reference) != len(candidate):
            raise ValueError(f"Output count differs: {name}")
        for index, (a, b) in enumerate(zip(reference, candidate)):
            if a[:2] != b[:2]:
                raise ValueError(f"Output type or shape differs: {name}, matrix {index}")
            atol, rtol = tolerances(name.split("__")[0], a[0], args.strict, index)
            maximum = 0.0
            squared = 0.0
            failed = 0
            function = name.split("__")[0]
            # With tied minima/maxima, OpenCV may validly return any matching
            # coordinate. The C++ suite checks each reported coordinate against
            # its own deterministic input; cross-build comparison covers values.
            if function == "minMaxLoc" and not args.strict:
                values_a, values_b = a[2][:2], b[2][:2]
                match = re.search(r"__(\d+)x(\d+)__", name)
                if not match:
                    raise ValueError(f"Cannot parse minMaxLoc input dimensions: {name}")
                width, height = map(int, match.groups())
                for values in (a[2], b[2]):
                    min_x, min_y, max_x, max_y = map(int, values[2:6])
                    if not (0 <= min_x < width and 0 <= max_x < width and
                            0 <= min_y < height and 0 <= max_y < height):
                        failed += 1
                pairs = zip(values_a, values_b)
                element_count = 2
            else:
                pairs = zip(a[2], b[2])
                element_count = len(a[2])
            for x, y in pairs:
                if not math.isfinite(x) or not math.isfinite(y):
                    failed += 1
                    maximum = squared = float("inf")
                    continue
                error = abs(x - y)
                maximum = max(maximum, error)
                squared += error * error
                failed += error > atol + rtol * abs(x)
            failures += failed > 0
            writer.writerow([name, index, element_count, atol, rtol, maximum,
                             math.sqrt(squared / max(1, element_count)), failed,
                             "FAIL" if failed else "PASS"])
    print(f"compared_cases={len(left)} failed_matrices={failures} strict={args.strict}", file=sys.stderr)
    return int(failures != 0)

if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, ValueError, struct.error) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        sys.exit(2)
