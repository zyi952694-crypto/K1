// New reproducibility suite, not the original SDK benchmark source.
#include <opencv2/core.hpp>
#include <opencv2/core/ocl.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/dnn.hpp>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>

struct CaseSpec {
    const char* module;
    const char* function;
    const char* api;
    int width, height;
    const char* outputSize;
};
const std::vector<CaseSpec> specs = {
#include "cases.inc"
};
struct Options {
    int iterations = 100;
    int threads = 0;
    bool check = false, list = false;
    std::string dumpDir, filter;
};
std::string quote(const std::string& s) {
    std::string result = "\"";
    for (char c : s) { result += c; if (c == '"') result += '"'; }
    return result + '"';
}
std::string sizeText(const CaseSpec& s) {
    return std::to_string(s.width) + "x" + std::to_string(s.height);
}
int integer(const std::string& s, int minimum, const char* option) {
    std::size_t pos = 0;
    const long n = std::stol(s, &pos);
    if (pos != s.size() || n < minimum || n > std::numeric_limits<int>::max())
        throw std::runtime_error(std::string("Invalid ") + option + ": " + s);
    return static_cast<int>(n);
}
Options options(int argc, char** argv) {
    Options o;
    for (int i = 1; i < argc; ++i) {
        const std::string arg = argv[i];
        auto value = [&]() -> std::string {
            if (++i >= argc) throw std::runtime_error("Missing value for " + arg);
            return argv[i];
        };
        if (arg == "--iterations") o.iterations = integer(value(), 1, "iterations");
        else if (arg == "--threads") o.threads = integer(value(), 0, "threads");
        else if (arg == "--dump-output-dir") o.dumpDir = value();
        else if (arg == "--filter") o.filter = value();
        else if (arg == "--check") o.check = true;
        else if (arg == "--list") o.list = true;
        else if (arg == "--help" || arg == "-h") {
            std::cout << "Usage: opencv_table_suite [--iterations 100] [--threads 0|1|8]\n"
                         "       [--check] [--dump-output-dir DIR] [--filter FUNCTION] [--list]\n"
                         "Warm-up: 10. threads=0 preserves OpenCV's default thread setting.\n"
                         "--check selects one representative row per function (25 total).\n"
                         "--dump-output-dir saves all selected outputs outside the timed region.\n"
                         "--list lists cases, types and parameters without executing operations.\n";
            std::exit(0);
        } else throw std::runtime_error("Unknown option: " + arg);
    }
    if (o.threads != 0 && o.threads != 1 && o.threads != 8)
        throw std::runtime_error("--threads must be 0, 1 or 8");
    return o;
}
// Fully specified generator, independent of OpenCV version and standard distributions.
struct Generator {
    std::uint32_t state = 0x4b330651u;
    std::uint32_t next() { state ^= state << 13; state ^= state >> 17; state ^= state << 5; return state; }
    void bytes(cv::Mat& m) {
        for (std::size_t i = 0; i < m.total() * m.elemSize(); ++i)
            m.data[i] = static_cast<unsigned char>(next() >> 24);
    }
    void floats(cv::Mat& m) {
        auto* p = m.ptr<float>();
        for (std::size_t i = 0; i < m.total() * m.channels(); ++i)
            p[i] = static_cast<float>(next() & 65535u) / 65536.0f;
    }
};
struct Case {
    CaseSpec spec;
    std::string name, type, parameters;
    cv::Mat bgr, overlay, gray, fp3, x, y, mapX, mapY, lut, kernel;
    cv::Mat out, out2, tmp;
    std::vector<cv::Mat> channels;
    double scalar = 0, minimum = 0, maximum = 0;
    cv::Point minLocation, maxLocation;
    explicit Case(const CaseSpec& s) : spec(s), name(s.function) {
        Generator rng;
        bgr.create(s.height, s.width, CV_8UC3); rng.bytes(bgr);
        overlay.create(s.height, s.width, CV_8UC3); rng.bytes(overlay);
        gray.create(s.height, s.width, CV_8UC1); rng.bytes(gray);
        fp3.create(s.height, s.width, CV_32FC3); rng.floats(fp3);
        x.create(s.height, s.width, CV_32FC1); rng.floats(x);
        y.create(s.height, s.width, CV_32FC1); rng.floats(y);
        type = "CV_8UC3->CV_8UC3";
        if (name == "resize_linear") parameters = "INTER_LINEAR; fx=fy=0; reusable dst";
        else if (name == "cvtColor_bgr2rgb") parameters = "COLOR_BGR2RGB";
        else if (name == "cvtColor_bgr2gray") { type = "CV_8UC3->CV_8UC1"; parameters = "COLOR_BGR2GRAY"; }
        else if (name == "normalize_uint8_to_fp32") { type = "CV_8UC3->CV_32FC3"; parameters = "alpha=1/255; beta=0"; }
        else if (name == "blobFromImage_bgr_fp32") { type = "CV_8UC3->CV_32F(NCHW)"; parameters = "scale=1/255; mean=0; swapRB=false; crop=false; same size"; }
        else if (name == "mean_std_normalize") { type = "CV_32FC3->CV_32FC3"; parameters = "subtract Scalar(0.485,0.456,0.406); divide Scalar(0.229,0.224,0.225); separate temporary"; }
        else if (name == "gaussian_blur_3x3") parameters = "ksize=3x3; sigmaX=sigmaY=0; BORDER_REFLECT_101";
        else if (name == "copy_make_border_32") parameters = "top=bottom=left=right=32; BORDER_CONSTANT; Scalar(114,114,114)";
        else if (name == "split_channels") { type = "CV_8UC3->3xCV_8UC1"; parameters = "B,G,R; reusable vector of Mat"; }
        else if (name == "threshold_otsu_gray") { type = "CV_8UC1->CV_8UC1+double"; parameters = "threshold=0; maxval=255; THRESH_BINARY|THRESH_OTSU; returned threshold retained"; }
        else if (name == "addWeighted_segmentation_mask") { type = "2xCV_8UC3->CV_8UC3"; parameters = "alpha=0.6; beta=0.4; gamma=0; synthetic 8-bit overlay"; }
        else if (name == "cartToPolar") { type = "2xCV_32FC1->2xCV_32FC1"; parameters = "angleInDegrees=false; x,y in [0,1)"; }
        else if (name == "compare") { type = "2xCV_32FC1->CV_8UC1"; parameters = "CMP_GT(x,y)"; }
        else if (name == "divide") { type = "CV_32FC3->CV_32FC3"; parameters = "divide(src,Scalar(0.229,0.224,0.225),dst); scale=1"; }
        else if (name == "dot") { type = "2xCV_32FC1->double"; parameters = "x.dot(y)"; }
        else if (name == "dft") { type = "CV_32FC1->CV_32FC2"; parameters = "DFT_COMPLEX_OUTPUT; nonzeroRows=0; unscaled forward transform"; }
        else if (name == "exp") { type = "CV_32FC1->CV_32FC1"; parameters = "x in [0,1)"; }
        else if (name == "flip_horizontal") parameters = "flipCode=1";
        else if (name == "LUT_invert") {
            parameters = "lut[i]=255-i; CV_8UC1 lookup table";
            lut.create(1, 256, CV_8UC1);
            for (int i = 0; i < 256; ++i) lut.at<unsigned char>(0, i) = static_cast<unsigned char>(255-i);
        } else if (name == "minMaxLoc") { type = "CV_32FC1->2xdouble+2xPoint"; parameters = "min/max values and reported locations; no mask"; }
        else if (name == "remap_identity") {
            parameters = "mapX/mapY CV_32FC1 integer coordinates; INTER_LINEAR; BORDER_CONSTANT=0";
            mapX.create(s.height,s.width,CV_32FC1); mapY.create(s.height,s.width,CV_32FC1);
            for (int r = 0; r < s.height; ++r) for (int c = 0; c < s.width; ++c) {
                mapX.at<float>(r,c) = static_cast<float>(c); mapY.at<float>(r,c) = static_cast<float>(r);
            }
        } else if (name == "transpose") parameters = "out-of-place";
        else if (name == "Canny") { type = "CV_8UC1->CV_8UC1"; parameters = "threshold1=100; threshold2=200; apertureSize=3; L2gradient=false"; }
        else if (name == "erode_dilate") {
            parameters = "MORPH_RECT 3x3; erode then dilate; anchor=(-1,-1); iterations=1; BORDER_CONSTANT; morphologyDefaultBorderValue";
            kernel = cv::getStructuringElement(cv::MORPH_RECT, cv::Size(3,3));
        } else if (name == "pyrDown_pyrUp") parameters = "half size then original size; BORDER_REFLECT_101; includes both calls";
        else throw std::runtime_error("Unknown function " + name);
    }
    void run() {
        if (name == "resize_linear") {
            const int n = std::stoi(spec.outputSize);
            cv::resize(bgr, out, cv::Size(n,n), 0, 0, cv::INTER_LINEAR);
        } else if (name == "cvtColor_bgr2rgb") cv::cvtColor(bgr, out, cv::COLOR_BGR2RGB);
        else if (name == "cvtColor_bgr2gray") cv::cvtColor(bgr, out, cv::COLOR_BGR2GRAY);
        else if (name == "normalize_uint8_to_fp32") bgr.convertTo(out, CV_32FC3, 1.0/255.0, 0);
        else if (name == "blobFromImage_bgr_fp32") cv::dnn::blobFromImage(bgr, out, 1.0/255.0, bgr.size(), cv::Scalar(), false, false, CV_32F);
        else if (name == "mean_std_normalize") { cv::subtract(fp3,cv::Scalar(0.485,0.456,0.406),tmp); cv::divide(tmp,cv::Scalar(0.229,0.224,0.225),out); }
        else if (name == "gaussian_blur_3x3") cv::GaussianBlur(bgr,out,cv::Size(3,3),0,0,cv::BORDER_REFLECT_101);
        else if (name == "copy_make_border_32") cv::copyMakeBorder(bgr,out,32,32,32,32,cv::BORDER_CONSTANT,cv::Scalar(114,114,114));
        else if (name == "split_channels") cv::split(bgr,channels);
        else if (name == "threshold_otsu_gray") scalar=cv::threshold(gray,out,0,255,cv::THRESH_BINARY|cv::THRESH_OTSU);
        else if (name == "addWeighted_segmentation_mask") cv::addWeighted(bgr,0.6,overlay,0.4,0,out);
        else if (name == "cartToPolar") cv::cartToPolar(x,y,out,out2,false);
        else if (name == "compare") cv::compare(x,y,out,cv::CMP_GT);
        else if (name == "divide") cv::divide(fp3,cv::Scalar(0.229,0.224,0.225),out);
        else if (name == "dot") scalar=x.dot(y);
        else if (name == "dft") cv::dft(x,out,cv::DFT_COMPLEX_OUTPUT,0);
        else if (name == "exp") cv::exp(x,out);
        else if (name == "flip_horizontal") cv::flip(bgr,out,1);
        else if (name == "LUT_invert") cv::LUT(bgr,lut,out);
        else if (name == "minMaxLoc") cv::minMaxLoc(x,&minimum,&maximum,&minLocation,&maxLocation);
        else if (name == "remap_identity") cv::remap(bgr,out,mapX,mapY,cv::INTER_LINEAR,cv::BORDER_CONSTANT,cv::Scalar());
        else if (name == "transpose") cv::transpose(bgr,out);
        else if (name == "Canny") cv::Canny(gray,out,100,200,3,false);
        else if (name == "erode_dilate") { cv::erode(bgr,tmp,kernel,cv::Point(-1,-1),1,cv::BORDER_CONSTANT,cv::morphologyDefaultBorderValue()); cv::dilate(tmp,out,kernel,cv::Point(-1,-1),1,cv::BORDER_CONSTANT,cv::morphologyDefaultBorderValue()); }
        else if (name == "pyrDown_pyrUp") { cv::pyrDown(bgr,tmp,cv::Size(spec.width/2,spec.height/2),cv::BORDER_REFLECT_101); cv::pyrUp(tmp,out,bgr.size(),cv::BORDER_REFLECT_101); }
    }
    std::vector<cv::Mat> outputs() const {
        if (name == "split_channels") return channels;
        if (name == "cartToPolar") return {out,out2};
        if (name == "dot") return {(cv::Mat_<double>(1,1) << scalar)};
        if (name == "minMaxLoc") return {(cv::Mat_<double>(1,6) << minimum,maximum,minLocation.x,minLocation.y,maxLocation.x,maxLocation.y)};
        if (name == "threshold_otsu_gray") return {out,(cv::Mat_<double>(1,1) << scalar)};
        return {out};
    }
};
std::string caseId(const CaseSpec& s) {
    return std::string(s.function) + "__" + sizeText(s) + "__" + s.outputSize;
}
// Version-1 binary format, little endian. Values are raw OpenCV Mat bytes.
void u32(std::ostream& out, std::uint32_t v) {
    for (unsigned i = 0; i < 4; ++i) out.put(static_cast<char>((v >> (8*i)) & 255u));
}
void dump(const std::filesystem::path& file, const std::vector<cv::Mat>& matrices) {
    const std::uint16_t endian = 1;
    if (*reinterpret_cast<const unsigned char*>(&endian) != 1) throw std::runtime_error("Output dumps require little endian host");
    std::ofstream out(file,std::ios::binary);
    out.exceptions(std::ios::failbit | std::ios::badbit);
    out.write("K3CVOUT1",8); u32(out,static_cast<std::uint32_t>(matrices.size()));
    for (const auto& original : matrices) {
        const cv::Mat m = original.isContinuous() ? original : original.clone();
        u32(out,static_cast<std::uint32_t>(m.type())); u32(out,static_cast<std::uint32_t>(m.dims));
        for (int d = 0; d < m.dims; ++d) u32(out,static_cast<std::uint32_t>(m.size[d]));
        const auto bytes=m.total()*m.elemSize();
        if (bytes>std::numeric_limits<std::uint32_t>::max()) throw std::runtime_error("Dump too large");
        u32(out,static_cast<std::uint32_t>(bytes));
        out.write(reinterpret_cast<const char*>(m.data),static_cast<std::streamsize>(bytes));
    }
}
double checksum(const std::vector<cv::Mat>& matrices) {
    long double total=0;
    for (std::size_t i=0;i<matrices.size();++i) {
        cv::Mat values; matrices[i].convertTo(values,CV_64F);
        if (!values.isContinuous()) values=values.clone();
        const double* p=values.ptr<double>();
        for (std::size_t j=0;j<values.total()*values.channels();++j) {
            if (!std::isfinite(p[j])) throw std::runtime_error("Non-finite output");
            total += static_cast<long double>(p[j]) * static_cast<long double>((i+1)*(1+j%251));
        }
    }
    return static_cast<double>(total);
}
int main(int argc,char** argv) {
    try {
        const Options o=options(argc,argv);
        // Zero deliberately does NOT call setNumThreads(0), which disables threading.
        if (o.threads>0) cv::setNumThreads(o.threads);
        cv::ocl::setUseOpenCL(false);
        const int actualThreads=cv::getNumThreads();
        std::cerr << "OpenCV=" << CV_VERSION << " requested_threads=" << o.threads
                  << " reported_threads=" << actualThreads << " warmup=10 iterations=" << o.iterations
                  << " seed=0x4b330651 check=" << o.check << "\n";
        if (!o.dumpDir.empty()) std::filesystem::create_directories(o.dumpDir);
        if (o.list) std::cout << "module,function,api,input_size,output_size,type,parameters\n";
        else std::cout << "module,function,api,input_size,output_size,type,iterations,threads,avg_ms,checksum\n";
        std::set<std::string> seen;
        int count=0;
        for (const auto& spec : specs) {
            if (!o.filter.empty() && o.filter!=spec.function) continue;
            if (o.check && !seen.insert(spec.function).second) continue;
            Case c(spec);
            const std::string prefix=quote(spec.module)+","+quote(spec.function)+","+quote(spec.api)+","+quote(sizeText(spec))+","+quote(spec.outputSize)+","+quote(c.type);
            if (o.list) { std::cout << prefix << ',' << quote(c.parameters) << '\n'; ++count; continue; }
            for (int n=0;n<10;++n) c.run();
            const auto start=cv::getTickCount();
            for (int n=0;n<o.iterations;++n) c.run();
            const auto end=cv::getTickCount();
            const double ms=1000.0*static_cast<double>(end-start)/cv::getTickFrequency()/o.iterations;
            // Equal extrema may occur at multiple coordinates; each implementation can
            // return a different valid coordinate. Validate its own coordinates against
            // the deterministic source matrix before comparing scalar extrema cross-build.
            if (c.name == "minMaxLoc") {
                const auto inBounds = [&](const cv::Point& p) {
                    return p.x >= 0 && p.x < c.x.cols && p.y >= 0 && p.y < c.x.rows;
                };
                if (!inBounds(c.minLocation) || !inBounds(c.maxLocation))
                    throw std::runtime_error("minMaxLoc returned a coordinate outside the input matrix");
                if (c.x.at<float>(c.minLocation.y, c.minLocation.x) != c.minimum ||
                    c.x.at<float>(c.maxLocation.y, c.maxLocation.x) != c.maximum)
                    throw std::runtime_error("minMaxLoc returned a coordinate that does not contain the reported extremum");
            }
            const auto result=c.outputs();
            const double sum=checksum(result);
            if (!o.dumpDir.empty()) dump(std::filesystem::path(o.dumpDir)/(caseId(spec)+".bin"),result);
            std::cout << prefix << ',' << o.iterations << ',' << actualThreads << ',' << std::setprecision(12) << ms << ',' << std::setprecision(17) << sum << '\n';
            std::cout.flush();
            ++count;
        }
        if (count==0) throw std::runtime_error("No cases selected");
        std::cerr << "completed_rows=" << count << '\n';
        return 0;
    } catch (const std::exception& e) { std::cerr << "ERROR: " << e.what() << '\n'; return 1; }
}
