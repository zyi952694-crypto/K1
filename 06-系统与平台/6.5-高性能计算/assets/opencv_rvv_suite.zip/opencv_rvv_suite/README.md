# OpenCV 性能对比测试套件

本套件为独立编写的测试程序，用于在 K1 上以相同代码、输入和参数比较系统 OpenCV 与 `opencv-spacemit` 两个发行构建。它包含 K3 OpenCV-RVV 文档附表所列的 25 类函数和 145 个尺寸组合：resize 的 5 种输入尺寸 × 5 种输出尺寸为 25 个案例，其余 24 类函数各有 5 个案例。

原附表没有公开所有算子的完整输入数据与参数。本套件使用下文说明的确定性合成输入和显式参数，不表示还原了 K3 原测试未公开的内部条件。库版本、编译器、优化选项和并行框架也会影响结果，因此两种发行构建的性能差异不能全部归因于 RVV。

## 环境与文件

要求 CMake、支持 C++17 的编译器、Python 3，以及包含 core、imgproc、dnn 模块的 OpenCV 4.6 或兼容的新版本。K1 上的两个 OpenCV 安装位置分别为：

- 系统库：`/usr/lib/riscv64-linux-gnu/cmake/opencv4`。
- `opencv-spacemit`：`/opt/opencv-spacemit/lib/cmake/opencv4`。

`compare_outputs.py` 仅使用 Python 标准库，不依赖 NumPy。性能测试中的 `taskset` 由 `util-linux` 包提供。

资源包包括 `CMakeLists.txt`、`main.cpp`、`cases.inc`、`compare_outputs.py`、参数清单 `cases-and-parameters.csv`、文件校验清单 `SHA256SUMS` 和本说明。将资源包解压到 `~/cv_test` 后，以下命令假定源码位于 `~/cv_test/opencv_rvv_suite`。

## 构建

使用两个独立构建目录，并明确指定各自的 OpenCV 配置路径：

```bash
cmake -S ~/cv_test/opencv_rvv_suite -B ~/cv_test/build-suite-system \
    -DOpenCV_DIR=/usr/lib/riscv64-linux-gnu/cmake/opencv4 \
    -DCMAKE_BUILD_TYPE=Release
cmake --build ~/cv_test/build-suite-system -j2

cmake -S ~/cv_test/opencv_rvv_suite -B ~/cv_test/build-suite-rvv \
    -DOpenCV_DIR=/opt/opencv-spacemit/lib/cmake/opencv4 \
    -DCMAKE_BUILD_TYPE=Release
cmake --build ~/cv_test/build-suite-rvv -j2
```

检查两次 CMake 的 `Found OpenCV` 输出，确认系统库与厂商库路径分别为 `/usr` 和 `/opt/opencv-spacemit`。测试其他安装位置时，应将 `OpenCV_DIR` 改为对应的 `OpenCVConfig.cmake` 所在目录。

## 性能测试与 CSV

默认每个案例预热 10 次、计时 100 次。程序将 CSV 写到标准输出，将 OpenCV 版本、线程报告值等运行信息写到标准错误输出。CSV 列为：

`module,function,api,input_size,output_size,type,iterations,threads,avg_ms,checksum`

`avg_ms` 为每次算子调用的平均毫秒数。`--threads 0` 不调用 `cv::setNumThreads`，保留该 OpenCV 构建的默认线程策略；`--threads 1` 和 `--threads 8` 分别设置线程数。CSV 中的 `threads` 是 `cv::getNumThreads()` 的返回值，该报告值不保证每个算子在执行时始终使用全部线程。

程序关闭 OpenCL，避免本套 CPU 对比混入 OpenCL 后端；程序本身不设置 CPU 亲和性，也不修改调度策略。以下命令在 K1 上分别使用 CPU 7 和 CPU 0–7，运行前可通过 `lscpu` 确认相应 CPU 在线。

```bash
cd ~/cv_test

# 单核：CPU 7，OpenCV 线程数为 1。
OPENCV_FOR_THREADS_NUM=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
    taskset -c 7 ./build-suite-system/opencv_table_suite --iterations 100 --threads 1 \
    > single_system.csv 2> single_system.log
OPENCV_FOR_THREADS_NUM=1 OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 \
    taskset -c 7 ./build-suite-rvv/opencv_table_suite --iterations 100 --threads 1 \
    > single_spacemit.csv 2> single_spacemit.log

# 多核：CPU 0–7，保留各库默认线程策略。
env -u OPENCV_FOR_THREADS_NUM -u OMP_NUM_THREADS -u OPENBLAS_NUM_THREADS -u MKL_NUM_THREADS \
    taskset -c 0-7 ./build-suite-system/opencv_table_suite --iterations 100 --threads 0 \
    > multi_system.csv 2> multi_system.log
env -u OPENCV_FOR_THREADS_NUM -u OMP_NUM_THREADS -u OPENBLAS_NUM_THREADS -u MKL_NUM_THREADS \
    taskset -c 0-7 ./build-suite-rvv/opencv_table_suite --iterations 100 --threads 0 \
    > multi_spacemit.csv 2> multi_spacemit.log
```

每份完整 CSV 应包含 145 行数据（另有 1 行表头）。比较前应确认两库的案例顺序、类型、输入输出尺寸、迭代数和线程设置一致，并记录各自的库版本。速度比按 `system_avg_ms / opencv-spacemit_avg_ms` 计算；大于 1 表示该案例中厂商库耗时较少，小于 1 表示系统库耗时较少。

可使用以下选项查看参数或调整测试范围：

```bash
cd ~/cv_test
./build-suite-system/opencv_table_suite --list > cases-and-parameters.csv
./build-suite-system/opencv_table_suite --threads 8 > eight-threads.csv
./build-suite-system/opencv_table_suite --iterations 1000 > longer.csv
./build-suite-system/opencv_table_suite --filter resize_linear > resize.csv
```

`--list` 只输出完整参数清单，不执行算子。`--filter` 按函数名筛选全部对应尺寸，`--filter resize_linear` 包含 25 个 resize 案例；目前不提供按案例行号筛选的选项。

resize 使用可复用的 `cv::Mat dst`，直接调用 `cv::resize(src,dst,target,0,0,INTER_LINEAR)`。输入生成、首次内存分配触发、校验和、CSV 和二进制文件写入均在计时区间之外；算子每次调用内部所需的工作仍计入耗时，例如 erode 后的 dilate、pyrDown 后的 pyrUp。

`checksum` 为输出矩阵全部数值的加权求和摘要，用于发现明显变化并确保结果被读取。Otsu 返回阈值、dot 和 minMaxLoc 标量也纳入摘要。该值不是抗碰撞校验，不能代替逐元素比较。

## 输出比较

输出比较以两套构建各自生成的二进制结果为输入。计时完成后，`--dump-output-dir` 将选中的结果写入指定目录；比较时两个目录应包含同一批案例，避免在不同测试范围之间复用输出目录。

### 完整 145 个案例

以下命令不使用 `--check` 或 `--filter`，因此覆盖完整 145 个尺寸案例。每例仍预热 10 次，随后执行 1 次计时调用并保存结果；这些调用用于输出比较，不用于生成性能附表。

```bash
cd ~/cv_test
output_check_dir=$(mktemp -d "$PWD/opencv-output-check.XXXXXX")

./build-suite-system/opencv_table_suite --iterations 1 --threads 1 \
    --dump-output-dir "$output_check_dir/system" \
    > "$output_check_dir/system.csv" 2> "$output_check_dir/system.log"
./build-suite-rvv/opencv_table_suite --iterations 1 --threads 1 \
    --dump-output-dir "$output_check_dir/spacemit" \
    > "$output_check_dir/spacemit.csv" 2> "$output_check_dir/spacemit.log"

python3 ./opencv_rvv_suite/compare_outputs.py \
    "$output_check_dir/system" "$output_check_dir/spacemit" \
    > "$output_check_dir/compare.csv"
```

所有案例生成成功时，每个输出目录包含 145 个 `.bin` 文件；部分算子包含多个输出矩阵，比较 CSV 共包含 165 行矩阵结果（另有 1 行表头）。`compare_outputs.py` 的标准错误输出报告案例数和失败矩阵数；退出码 `0` 表示满足当前比较规则，`1` 表示存在数值比较失败，`2` 表示目录、文件结构或读取等错误。输出比较通过只表示这些合成输入满足所列工程阈值，不是对所有输入的算法正确性保证。

### 每函数一个代表案例

快速检查可添加 `--check`。它为每类函数选择表中第一个尺寸，共 25 个案例；resize 为 1280×720→224×224，其余函数取各自的第一个输入尺寸。该模式不是完整 145 个案例的替代。

```bash
cd ~/cv_test
representative_check_dir=$(mktemp -d "$PWD/opencv-representative-check.XXXXXX")

./build-suite-system/opencv_table_suite --check --iterations 1 --threads 1 \
    --dump-output-dir "$representative_check_dir/system" \
    > "$representative_check_dir/system.csv" 2> "$representative_check_dir/system.log"
./build-suite-rvv/opencv_table_suite --check --iterations 1 --threads 1 \
    --dump-output-dir "$representative_check_dir/spacemit" \
    > "$representative_check_dir/spacemit.csv" 2> "$representative_check_dir/spacemit.log"

python3 ./opencv_rvv_suite/compare_outputs.py \
    "$representative_check_dir/system" "$representative_check_dir/spacemit" \
    > "$representative_check_dir/compare.csv"
```

### 文件格式和数值规则

二进制文件采用本套件定义的 `K3CVOUT1` little-endian 格式，文件名为 `function__input_size__output_size.bin`，内容包括矩阵个数、OpenCV type、维数、各维尺寸、字节长度及原始矩阵数据。

比较脚本检查文件集合、输出结构和数值。对于参考值 `x` 与待比较值 `y`，默认通过条件为 `abs(x-y) <= atol + rtol*abs(x)`；NaN 或 Inf 视为失败。以下阈值是本工具的工程筛查标准，不是 OpenCV 或 SDK 的兼容性保证：

| 输出类别 | atol | rtol |
| --- | ---: | ---: |
| `resize_linear`、`cvtColor_bgr2gray`、`gaussian_blur_3x3`、`addWeighted_segmentation_mask`、`pyrDown_pyrUp` 的 uint8 输出 | 1 灰阶级 | 0 |
| 其他 uint8 输出 | 0 | 0 |
| `threshold_otsu_gray` 的返回阈值、`minMaxLoc` 的极值 | 0 | 0 |
| DFT 浮点输出 | 0.005 | 0.0001 |
| dot 标量 | 1e-8 | 1e-6 |
| `cartToPolar` 幅值 | 1e-5 | 1e-5 |
| `cartToPolar` 角度（弧度） | `0.3*pi/180`，约 0.005236 | 0 |
| 其余浮点输出 | 2e-6 | 2e-6 |

`cartToPolar` 角度筛查阈值参考 OpenCV 接口所述约 0.3° 精度，实际可接受误差仍需按业务要求评估。`minMaxLoc` 默认比较极值数值并检查坐标范围；输入存在相同极值时，两库可以返回不同但有效的位置。C++ 测试程序还会核对各自返回位置处的输入值确为对应极值。

添加 `--strict` 可要求全部数值严格相等，包括 `minMaxLoc` 坐标；该选项可用于检查相同构建等场景的数值确定性。不同版本、编译器和 SIMD 路径可能产生合理的浮点差异，存在并列极值时也可能返回不同坐标，应结合 `compare.csv` 中的最大绝对误差、RMSE 和失败元素数评估。

```bash
python3 ~/cv_test/opencv_rvv_suite/compare_outputs.py --strict \
    "$output_check_dir/system" "$output_check_dir/spacemit" \
    > "$output_check_dir/compare-strict.csv"
```

## 类型与参数约定

`--list` 输出完整机器可读清单；主要约定如下：

- 随机种子固定为 `0x4b330651`，使用 xorshift32，不使用 `cv::randu` 或标准库随机分布。字节输入取每步 PRNG 的高 8 位；浮点输入按 `(next() & 65535) / 65536.0f` 落在 `[0,1)`。测试不依赖外部图像。
- BGR 字节输入为 `CV_8UC3`；灰度算子使用独立 `CV_8UC1` 输入；浮点图由独立 `CV_32FC1` / `CV_32FC3` 输入产生。overlay 与主 BGR 图各自使用 PRNG 后续状态。
- resize 使用 `INTER_LINEAR`、`fx=fy=0` 和可复用输出缓冲。cvtColor 使用 `COLOR_BGR2RGB` / `COLOR_BGR2GRAY`；convertTo 输出 `CV_32FC3`，alpha=`1/255`、beta=0。
- `blobFromImage` 输出 FP32 NCHW，scale=`1/255`、无均值、无 RB 交换、无裁切，保持源尺寸。mean/std 输入为 `[0,1)` 的 `CV_32FC3`，依次减去 `(0.485,0.456,0.406)` 并逐通道除以 `(0.229,0.224,0.225)`，包含独立的中间输出。
- Gaussian blur 使用 3×3 核、sigmaX=sigmaY=0、`BORDER_REFLECT_101`。四边各补 32 像素，使用常量 `(114,114,114)`。split 将 BGR 拆成三个 `CV_8UC1` 平面并复用矩阵向量。Otsu 使用 binary、maxval=255，同时保留返回阈值。
- `addWeighted` 的两图系数为 0.6/0.4、gamma=0；`cartToPolar` 使用两个独立 `[0,1)` 浮点平面且角度单位为弧度；compare 为 `CMP_GT`；divide 逐通道除以上述标准差，scale=1；dot 为两个浮点平面的内积。
- DFT 为前向未缩放变换，使用 `DFT_COMPLEX_OUTPUT`、nonzeroRows=0；exp 输入为 `[0,1)`；水平翻转使用 flipCode=1；LUT 使用 `lut[i]=255-i`。
- `minMaxLoc` 对浮点单通道输入取最小值、最大值及其坐标，不使用 mask。remap 的两个单通道坐标表按整数像素坐标构成 identity map，使用 linear 插值和常量零边界。transpose 为非原地转置。
- Canny 使用灰度输入、阈值 100/200、3×3 aperture、L2=false。形态学使用矩形 3×3 核，先 erode 再 dilate，各迭代一次，anchor=(-1,-1)、`BORDER_CONSTANT`、`morphologyDefaultBorderValue`。
- pyrDown 到半尺寸后再 pyrUp 到原尺寸，两步均计时，边界为 `BORDER_REFLECT_101`。

这些参数是本套件公开的测试条件。性能数字应与对应的 OpenCV 构建、线程设置和输入参数一起使用；输出比较结论应注明完整 145 案例或 25 个代表案例的实际覆盖范围。
