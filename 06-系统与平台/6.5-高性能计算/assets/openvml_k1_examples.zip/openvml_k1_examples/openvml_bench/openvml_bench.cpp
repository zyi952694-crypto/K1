#include <openvml.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstdlib>
#include <iomanip>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <type_traits>
#include <vector>

struct Settings { size_t n; int iterations, warmup; };
struct Result {
  std::string api; size_t n, output_n; int iterations, warmup;
  double total_ms=0, checksum=0, max_abs=0, max_rel=0;
  size_t mismatches=0, guards=0;
};
static void emit(const Result& r) {
  double avg=r.iterations ? r.total_ms/r.iterations : 0;
  std::cout << std::setprecision(17)
    << "{\"api\":\"" << r.api << "\",\"n\":" << r.n
    << ",\"output_n\":" << r.output_n << ",\"iterations\":" << r.iterations
    << ",\"warmup\":" << r.warmup << ",\"total_ms\":" << r.total_ms
    << ",\"avg_ms\":" << avg << ",\"mevals_per_second\":" << (avg ? r.n/avg/1000 : 0)
    << ",\"checksum\":" << r.checksum << ",\"max_abs_error\":" << r.max_abs
    << ",\"max_rel_error\":" << r.max_rel << ",\"mismatches\":" << r.mismatches
    << ",\"guard_errors\":" << r.guards << ",\"valid\":" << ((r.mismatches+r.guards)==0 ? "true":"false") << "}\n";
}
template<class T> void check(Result& r, const std::vector<T>& output,
                             const std::vector<double>& ref, double atol,
                             double rtol, T sentinel) {
  for(size_t i=0;i<ref.size();++i) {
    double got=output[i+8], expected=ref[i];
    double err=std::abs(got-expected);
    if(!std::isfinite(got) || err>atol+rtol*std::abs(expected)) {
      if(r.mismatches<3)std::cerr<<r.api<<" mismatch index="<<i<<" got="<<std::setprecision(17)<<got<<" expected="<<expected<<'\n';
      ++r.mismatches;
    }
    r.max_abs=std::max(r.max_abs,static_cast<double>(err));
    r.max_rel=std::max(r.max_rel,static_cast<double>(err/std::max(std::abs(expected),1e-30)));
    r.checksum+=static_cast<double>(got);
  }
  for(size_t i=0;i<8;++i) {
    if(output[i]!=sentinel) ++r.guards;
    if(output[ref.size()+8+i]!=sentinel) ++r.guards;
  }
}
template<class Call> double measure(Call call, const Settings& s) {
  call();
  for(int i=0;i<s.warmup;++i) call();
  auto start=std::chrono::steady_clock::now();
  for(int i=0;i<s.iterations;++i) call();
  return std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
}
static double unary_ref(const std::string& f,double x) {
  if(f=="Abs")return std::abs(x);
  if(f=="Recip")return 1/x;
  if(f=="Sqrt")return std::sqrt(x);
  if(f=="Sqr")return x*x;
  if(f=="Pow2o3")return std::pow(x,2.0/3.0);
  if(f=="Pow3o2")return std::pow(x,1.5);
  if(f=="Exp")return std::exp(x);
  if(f=="Expm1")return std::expm1(x);
  if(f=="Log10")return std::log10(x);
  if(f=="Ln")return std::log(x);
  if(f=="Log1p")return std::log1p(x);
  if(f=="Tanh")return std::tanh(x);
  if(f=="Round")return std::round(x);
  if(f=="Ceil")return std::ceil(x);
  if(f=="Floor")return std::floor(x);
  if(f=="Sin"||f=="SinCos")return std::sin(x);
  if(f=="Cos")return std::cos(x);
  if(f=="Tan")return std::tan(x);
  if(f=="Asin")return std::asin(x);
  if(f=="Acos")return std::acos(x);
  if(f=="Atan")return std::atan(x);
  throw std::runtime_error("unknown unary "+f);
}
#define UNARY(P,F) if(api==#P #F) { P##F(n,a.data(),y.data()+8); return; }
#define BINARY(P,F) if(api==#P #F) { P##F(n,a.data(),b.data(),y.data()+8); return; }
#define FLOAT_DISPATCH(P) \
 UNARY(P,Abs) UNARY(P,Recip) UNARY(P,Sqrt) UNARY(P,Sqr) \
 UNARY(P,Pow2o3) UNARY(P,Pow3o2) UNARY(P,Exp) UNARY(P,Expm1) \
 UNARY(P,Log10) UNARY(P,Ln) UNARY(P,Log1p) UNARY(P,Tanh) \
 UNARY(P,Round) UNARY(P,Ceil) UNARY(P,Floor) UNARY(P,Sin) \
 UNARY(P,Cos) UNARY(P,Tan) UNARY(P,Asin) UNARY(P,Acos) UNARY(P,Atan) \
 UNARY(P,Sum) BINARY(P,Add) BINARY(P,Sub) BINARY(P,Pow) BINARY(P,Powx) BINARY(P,Atan2) \
 if(api==#P "SinCos") { P##SinCos(n,a.data(),y.data()+8,z.data()+8); return; }

template<class T> Result floating(const std::string& api,const Settings& s) {
  std::string f=api.substr(2);
  bool reduce=f=="Sum"||f=="Dot", pair=f=="SinCos";
  size_t out_n=reduce?1:s.n;
  Result r{api,s.n,out_n,s.iterations,s.warmup};
  const T sentinel=T(12345.125);
  std::vector<T>a(s.n),b(s.n),y(out_n+16,sentinel),z(out_n+16,sentinel);
  std::vector<double>ref(out_n),ref_z(out_n);
  bool positive=f=="Recip"||f=="Sqrt"||f=="Pow2o3"||f=="Pow3o2"||f=="Log10"||f=="Ln"||f=="Log1p"||f=="Pow"||f=="Powx";
  for(size_t i=0;i<s.n;++i) {
    a[i]=positive ? T(.25+(i%97)/64.0) : T((int(i%97)-48)/64.0+.00390625);
    b[i]=T(.5+(i%53)/64.0);
    if(reduce) { a[i]=T((i%4+1)*.25); b[i]=T((i%4+1)*.5); }
  }
  if(f=="Powx") b[0]=T(.5);
  if(f=="Offset") b[0]=T(.5);
  if(f=="Scale") b[0]=T(3);
  for(size_t i=0;i<s.n;++i) {
    double x=a[i],v=b[i],expected=0;
    if(f=="Sum") {ref[0]+=x;continue;}
    if(f=="Dot") {ref[0]+=x*v;continue;}
    if(f=="Add")expected=x+v;
    else if(f=="Sub")expected=x-v;
    else if(f=="Mul")expected=x*v;
    else if(f=="Pow")expected=std::pow(x,v);
    else if(f=="Powx")expected=std::pow(x,(double)b[0]);
    else if(f=="Atan2")expected=std::atan2(x,v);
    else if(f=="Offset")expected=x+b[0];
    else if(f=="Scale")expected=x*b[0];
    else expected=unary_ref(f,x);
    ref[i]=expected;
    if(pair)ref_z[i]=std::cos(x);
  }
  VML_INT n=static_cast<VML_INT>(s.n);
  auto call=[&] {
    if constexpr(std::is_same_v<T,float>) {
      FLOAT_DISPATCH(vs)
      BINARY(vs,Mul) BINARY(vs,Dot) BINARY(vs,Offset) BINARY(vs,Scale)
    } else { FLOAT_DISPATCH(vd) }
    throw std::runtime_error("unsupported API "+api);
  };
  r.total_ms=measure(call,s);
  double atol=std::is_same_v<T,float>?2e-6:2e-13;
  double rtol=std::is_same_v<T,float>?2e-5:2e-12;
  check(r,y,ref,atol,rtol,sentinel);
  if(pair)check(r,z,ref_z,atol,rtol,sentinel);
  return r;
}
#define INT_DISPATCH(P) \
 if(api==#P "Add")P##Add(n,a.data(),b.data(),wide.data()+8); \
 else if(api==#P "Mul")P##Mul(n,a.data(),b.data(),wide.data()+8); \
 else if(api==#P "Dot")P##Dot(n,a.data(),b.data(),wide.data()+8); \
 else if(api==#P "Sub")P##Sub(n,a.data(),b.data(),narrow.data()+8); \
 else if(api==#P "Shift")P##Shift(n,a.data(),&shift,narrow.data()+8); \
 else if(api==#P "Scale")P##Scale(n,a.data(),scale,narrow.data()+8); \
 else if(api==#P "Offset")P##Offset(n,a.data(),offset,narrow.data()+8); \
 else throw std::runtime_error("unsupported API "+api);

template<class T> Result integer(const std::string& api,const Settings& s) {
  auto pos=api.find_first_not_of("0123456789",2);std::string f=api.substr(pos);
  bool widened=f=="Add"||f=="Mul"||f=="Dot";
  size_t out_n=f=="Dot"?1:s.n;
  Result r{api,s.n,out_n,s.iterations,s.warmup};
  const T sentinel=T(99);
  std::vector<T>a(s.n),b(s.n),narrow(out_n+16,sentinel);
  std::vector<int32_t>wide(out_n+16,123456789);
  std::vector<double>ref(out_n);
  const int32_t shift=1,scale=3;const T offset=T(2);
  for(size_t i=0;i<s.n;++i) {
    // Small nonnegative shift inputs avoid signed-shift undefined behavior.
    a[i]=f=="Shift"?T(i%16):T(int(i%17)-8);
    b[i]=T(int(i%13)-6);
    int64_t x=a[i],v=b[i],expected=0;
    if(f=="Dot"){ref[0]+=x*v;continue;}
    if(f=="Add")expected=x+v;
    else if(f=="Sub")expected=x-v;
    else if(f=="Mul")expected=x*v;
    else if(f=="Shift")expected=x*(int64_t(1)<<shift);
    else if(f=="Scale")expected=x*scale;
    else if(f=="Offset")expected=x+offset;
    ref[i]=expected;
  }
  VML_INT n=static_cast<VML_INT>(s.n);
  auto call=[&] {
    if constexpr(std::is_same_v<T,int8_t>){INT_DISPATCH(vs8)}
    else if constexpr(std::is_same_v<T,int16_t>){INT_DISPATCH(vs16)}
    else {INT_DISPATCH(vs32)}
  };
  r.total_ms=measure(call,s);
  if(widened)check(r,wide,ref,0,0,int32_t(123456789));
  else check(r,narrow,ref,0,0,sentinel);
  return r;
}
int main(int argc,char**argv) {
  try {
    if(argc!=5)throw std::runtime_error("usage: openvml_bench API N ITERATIONS WARMUP");
    std::string api=argv[1];
    Settings s{std::stoull(argv[2]),std::stoi(argv[3]),std::stoi(argv[4])};
    if(!s.n||s.n>2147483647||s.iterations<0||s.warmup<0)throw std::runtime_error("invalid settings");
    Result r;
    if(api.rfind("vd",0)==0)r=floating<double>(api,s);
    else if(api.rfind("vs8",0)==0)r=integer<int8_t>(api,s);
    else if(api.rfind("vs16",0)==0)r=integer<int16_t>(api,s);
    else if(api.rfind("vs32",0)==0)r=integer<int32_t>(api,s);
    else r=floating<float>(api,s);
    emit(r);return (r.mismatches+r.guards)?1:0;
  } catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 2;}
}
