# OpenVML K1 算子套件

本目录为 K1 教程新增的可复现套件；覆盖 K3 附录列出的 81 个 API。K3 附录未提供原始测试程序，因此本套件的输入和校验规则不代表 K3 原测试参数。

## 编译与运行

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release -DOPENVML_PREFIX="$HOME/openvml-package/rootfs/opt/openvml-spacemit"
cmake --build build -j2
OMP_NUM_THREADS=1 OPENVML_NUM_THREADS=1 taskset -c 0 python3 run_suite.py --exe ./build/openvml_bench --out results
```

`run_suite.py` 对每个 API 独立启动进程：先校验长度 1、7、31、257、1031，再对长度 1048576 预热 10 次、计时 50 次。验证和校验和计算均在计时区间外。任一调用失败、超时、输出不符或哨兵被破坏时，运行器最终返回非零状态。

输出包括 `results.json`、逐调用 `raw_results.jsonl`、性能表 `benchmark.csv` 和 `summary.json`。`avg_ms=total_ms/iterations`；`mevals_per_second=n/avg_ms/1000`。吞吐以输入元素数计算，SinCos 同时生成正弦和余弦两个输出数组，仍只计 n 个输入元素。数据类型列表示输入类型；int8/int16 的 Add、Mul 和所有整数 Dot 返回 int32。

## 输入与校验

- 浮点默认输入：`a[i]=((i%97)-48)/64+1/256`、`b[i]=1/2+(i%53)/64`。
- 倒数、平方根、2/3 次幂、3/2 次幂、对数和幂运算使用正输入：`a[i]=1/4+(i%97)/64`。反三角函数输入位于 (-1,1)。
- 浮点归约使用可精确表示的小数：`a[i]=((i%4)+1)/4`、`b[i]=((i%4)+1)/2`，减少归约顺序对误差判断的干扰。
- Powx 和 Offset 的标量参数为 1/2，Scale 为 3；它们按接口传入标量指针。
- 整数输入：`a[i]=(i%17)-8`、`b[i]=(i%13)-6`。Shift 输入为 `i%16`，左移 1 位；Scale 为 3，Offset 为 2。所有测试值均避免整数溢出。
- 每个输出元素与独立标量计算对照。float32 使用 `abs_error <= 2e-6 + 2e-5*abs(reference)`；float64 使用 `abs_error <= 2e-13 + 2e-12*abs(reference)`；整数要求完全相等。浮点参考使用系统标准数学库 double 运算。
- 每个输出缓冲区的首尾各放 8 个哨兵，同时验证双输出和归约输出边界。输入选取正常有限值，本套件不覆盖 NaN、无穷大、定义域外值、溢出和所有舍入临界点。

可单独执行一个 API，例如：

```bash
./build/openvml_bench vsSqrt 1048576 50 10
```
