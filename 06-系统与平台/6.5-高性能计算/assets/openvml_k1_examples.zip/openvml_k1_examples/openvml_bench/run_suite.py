#!/usr/bin/env python3
"""Run each public API in its own process and retain every raw result."""
import argparse, csv, json, os, pathlib, signal, subprocess, sys, time
p=argparse.ArgumentParser()
p.add_argument('--exe',required=True)
p.add_argument('--out',default='results')
p.add_argument('--n',type=int,default=1048576)
p.add_argument('--iterations',type=int,default=50)
p.add_argument('--warmup',type=int,default=10)
a=p.parse_args()
base=pathlib.Path(__file__).resolve().parent
out=pathlib.Path(a.out);out.mkdir(parents=True,exist_ok=True)
operators=json.loads((base/'operators.json').read_text())
records=[]
(out/'raw_results.jsonl').write_text('')
for op in operators:
    api=op['api']
    for n,it,warmup,phase in [(n,0,0,'correctness') for n in [1,7,31,257,1031]]+[(a.n,a.iterations,a.warmup,'benchmark')]:
        cmd=[a.exe,api,str(n),str(it),str(warmup)]
        start=time.time()
        try:
            result=subprocess.run(cmd,capture_output=True,text=True,timeout=180)
        except subprocess.TimeoutExpired as exc:
            def decode(value):
                return value.decode(errors='replace') if isinstance(value,bytes) else (value or '')
            result=subprocess.CompletedProcess(cmd,124,decode(exc.stdout),decode(exc.stderr)+'\nTIMEOUT after 180 seconds')
        entry={**op,'phase':phase,'command':cmd,'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,'wall_seconds':time.time()-start}
        try: entry['result']=json.loads(result.stdout)
        except json.JSONDecodeError: entry['result']=None
        records.append(entry)
        with (out/'raw_results.jsonl').open('a') as f:f.write(json.dumps(entry)+'\n')
        print(f"{phase} {api} n={n} rc={result.returncode} {result.stdout.strip()}",flush=True)
        if result.returncode < 0:
            # Unsupported instructions are deterministic; do not repeat a fault at larger sizes.
            break
    (out/'results.json').write_text(json.dumps({'settings':vars(a),'affinity':sorted(os.sched_getaffinity(0)),'OMP_NUM_THREADS':os.getenv('OMP_NUM_THREADS'),'OPENVML_NUM_THREADS':os.getenv('OPENVML_NUM_THREADS'),'records':records},indent=2)+'\n')
bench=[]
for e in records:
    if e['phase']=='benchmark' and e['result']:
        bench.append({**{k:e[k] for k in ['module','function','api','expression','dtype']},**e['result']})
if bench:
    with (out/'benchmark.csv').open('w') as f:
        writer=csv.DictWriter(f,fieldnames=list(bench[0]));writer.writeheader();writer.writerows(bench)
summary={'operators':len(operators),'records':len(records),'benchmark_rows':len(bench),'successful_records':sum(e['returncode']==0 for e in records),'failed_records':sum(e['returncode']!=0 for e in records),'failed_apis':sorted(set(e['api'] for e in records if e['returncode']!=0))}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary),flush=True)
sys.exit(1 if summary['failed_records'] else 0)
