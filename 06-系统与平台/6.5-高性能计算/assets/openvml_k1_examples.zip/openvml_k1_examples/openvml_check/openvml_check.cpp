#include <openvml.h>

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <numeric>
#include <vector>

double max_abs_error(const std::vector<float>& x, const std::vector<float>& y) {
  double err = 0.0;
  for (size_t i = 0; i < x.size(); ++i) {
    err = std::max(err, std::abs(static_cast<double>(x[i]) - static_cast<double>(y[i])));
  }
  return err;
}

int main() {
  const VML_INT n = 8;
  std::vector<float> x{0.25f, 1.0f, 2.25f, 4.0f, 6.25f, 9.0f, 12.25f, 16.0f};
  std::vector<float> y{1.0f, 2.0f, 3.0f, 4.0f, 5.0f, 6.0f, 7.0f, 8.0f};
  std::vector<float> sqrt_out(n);
  std::vector<float> add_out(n);
  std::vector<float> sqrt_ref(n);
  std::vector<float> add_ref(n);
  float sum_out = 0.0f;

  vsSqrt(n, x.data(), sqrt_out.data());
  vsAdd(n, x.data(), y.data(), add_out.data());
  vsSum(n, x.data(), &sum_out);

  for (VML_INT i = 0; i < n; ++i) {
    sqrt_ref[static_cast<size_t>(i)] = std::sqrt(x[static_cast<size_t>(i)]);
    add_ref[static_cast<size_t>(i)] = x[static_cast<size_t>(i)] + y[static_cast<size_t>(i)];
  }
  const float sum_ref = std::accumulate(x.begin(), x.end(), 0.0f);

  const double sqrt_err = max_abs_error(sqrt_out, sqrt_ref);
  const double add_err = max_abs_error(add_out, add_ref);
  const double sum_err = std::abs(static_cast<double>(sum_out) - static_cast<double>(sum_ref));

  std::cout << std::fixed << std::setprecision(6);
  std::cout << "OpenVML config: " << openvml_get_config() << '\n';
  std::cout << "vsSqrt max_abs_error=" << sqrt_err << '\n';
  std::cout << "vsAdd max_abs_error=" << add_err << '\n';
  std::cout << "vsSum abs_error=" << sum_err << '\n';

  if (sqrt_err > 1e-5 || add_err > 1e-5 || sum_err > 1e-5) {
    std::cerr << "OpenVML result: FAIL - result mismatch\n";
    return 1;
  }

  std::cout << "OpenVML result: PASS - linked OpenVML and computed correctly.\n";
  return 0;
}
