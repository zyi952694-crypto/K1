# K1 OpenVML 示例资源

- `openvml_check/`：教程中的完整最小示例（CMakeLists.txt 与 C++ 程序）。
- `openvml_bench/`：81 项 API 的独立进程验证与单核性能测试，输入及误差标准见该目录 README.md。

先按教程在 `~/openvml-package/rootfs` 解包固定版本官方 OpenVML 包，再在相应目录配置和运行。示例通过 CMake 的 OPENVML_PREFIX 指向解包目录。

原始最小示例无需修改源码。附录套件为 K1 新增，计时包含库函数调用，不含输入生成、标准数学库参考计算、输出检查与校验和计算。
